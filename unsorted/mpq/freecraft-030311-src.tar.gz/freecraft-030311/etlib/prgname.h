#ifndef ETLIB_PRGNAME_H
#define ETLIB_PRGNAME_H

extern char *prgname;
void setprgname(char *argv_0);

#endif /* ETLIB_PRGNAME_H */
