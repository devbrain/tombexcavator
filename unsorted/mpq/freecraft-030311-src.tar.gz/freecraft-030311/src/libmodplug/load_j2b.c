/*
 * This source code is public domain.
 *
 * Authors: Olivier Lapicque <olivierl@jps.net>
 *
 *	$Id: load_j2b.c,v 1.1 2001/11/07 23:36:13 johns Exp $
*/


///////////////////////////////////////////////////
//
// J2B module loader
//
///////////////////////////////////////////////////

#include "stdafx.h"
#include "sndfile.h"
