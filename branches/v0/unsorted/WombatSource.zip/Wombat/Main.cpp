//---------------------------------------------------------------------------

#include <vcl.h>
#include <filectrl.hpp>
#pragma hdrstop

#include "Main.h"
#include "levelViewer.h"
#include "mbash.h"
#include <iostream>
#include "cosmo.h"
#include "duke2.h"
#include "xatax.h"
#include "wackyw.h"
#include "cannon.h"
#include "dune2.h"
#include "mstryker.h"
#include "crystalcaves.h"
#include "gateworld.h"
#include "duke1.h"
#include "secretagent.h"
#include "redwoodEd.h"
#include "dynamic.h"
#include "dynamicVGA.h"
#include "dynamiccpl.h"
#include "dynamiccplVGA.h"
#include "clyde1.h"
#include "clyde2.h"
#include "comic1.h"
#include "keen13.h"
#include "hocus.h"
#include "title.h"
#include "sndPlayer.h"

#include <mmsystem.hpp>

const driverCount = 19;

IWombatGame *drivers[driverCount] = {new CWGame_Cannon, new CWGame_Clyde1, new CWGame_Clyde2, new CWGame_Comic1, /*new CWGame_Keen13,*/ new CWGame_Cosmo, new CWGame_CrystalCaves, new CWGame_Duke1, new CWGame_Duke2, new CWGame_Dune2,
                                     new CWGame_GateWorld, new CWGame_Hocus, new CWGame_MStryker, new CWGame_MonsterBash, /*new CWGame_PickleWars,*/ new CWGame_RedwoodEd, new CWGame_SecretAgent, new CWGame_WackyWheels, new CWGame_Xatax, new CWGame_Dynamic,
                                     new CWGame_DynamicVGA};
IWombatGame *currentDriver = NULL;

using namespace std;

char * currentData = NULL;
int currentDataSize = 0;
TPoint bitmapSize;
bool isSound;

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
TfrmMain *frmMain;
//---------------------------------------------------------------------------
__fastcall TfrmMain::TfrmMain(TComponent* Owner)
        : TForm(Owner)
{
}

void __fastcall TfrmMain::resetControls()
{
        spdExtract->Enabled = false;
        btnSaveImage->Enabled = false;
        imgImage->Visible = false;
        pnlSpeakerSound->Visible = false;
        pnlLevel->Visible = false;
        mmoText->Visible = false;

        if (medMedia->Mode == mpPlaying)
        {
                medMedia->Stop();
                medMedia->Close();
        }

        Caption = "Wombat Game Tools - " + currentDriver->getName();
        lblDriver->Caption = currentDriver->getCredits();
        if (currentDriver->getName() == "Unknown EGA image")
                frmDynamicCpl->Show();
        else
        if (currentDriver->getName() == "Unknown VGA image")
                frmDynamicCplVGA->Show();     
        else
                frmDynamicCpl->Hide();
}

void __fastcall TfrmMain::clearTreeView()
{
        for (int i = 0; i < trvGame->Items->Count; i++)
                if (trvGame->Items->Item[i]->Count == 0)
                        delete trvGame->Items->Item[i]->Data;
}

//---------------------------------------------------------------------------
void __fastcall TfrmMain::spdOpenClick(TObject *Sender)
{        
        TPoint mousePoint;
        GetCursorPos(&mousePoint);
        popGame->Popup(mousePoint.x, mousePoint.y);
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::openFileClick(TObject *Sender)
{
        opnOpenFile->Filter = "All supported files|*.diz;*.txt;" + drivers[((TComponent*)Sender)->Tag]->getFileExtensions() + "|All files|*.*";
        opnOpenFile->Title = "Open " + drivers[((TComponent*)Sender)->Tag]->getName() + " file";
        if (opnOpenFile->Execute())
        {
                currentDriver = drivers[((TComponent*)Sender)->Tag];
                currentDriver->loadFile(opnOpenFile->FileName, true);
                resetControls();
        }
}


void __fastcall TfrmMain::openDirClick(TObject *Sender)
{
        char c[256];
        GetCurrentDirectory(256, c);
        AnsiString s = (AnsiString)c;
        if (SelectDirectory("Open " + drivers[((TComponent*)Sender)->Tag]->getName() + " file", "", s))
        {
                currentDriver = drivers[((TComponent*)Sender)->Tag];
                currentDriver->loadDirectory(s);
                resetControls();
        }
}

void __fastcall TfrmMain::trvGameExpanding(TObject *Sender,
      TTreeNode *Node, bool &AllowExpansion)
{
        Node->ImageIndex = 0;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::trvGameCollapsing(TObject *Sender,
      TTreeNode *Node, bool &AllowCollapse)
{
        Node->ImageIndex = 2;
}
//---------------------------------------------------------------------------


void __fastcall TfrmMain::trvGameChange(TObject *Sender, TTreeNode *Node)
{
        frmMain->spnPlanes->Visible = false;
        frmMain->spnPlanes->Value = 5;
        if (medMedia->Mode == mpPlaying)
        {
                medMedia->Stop();
                medMedia->Close();
        }
        if (Node->Count != 0)
        {
                //folder
                frmMain->imgImage->Visible = false;
                frmMain->mmoText->Visible = false;
                frmMain->pnlLevel->Visible = false;
                frmMain->pnlSpeakerSound->Visible = false;
                frmMain->btnSaveImage->Enabled = false;
                frmMain->lblSaveImage->Enabled = false;
        }
        else
        {
                spdExtract->Enabled = ((CGameObject*)Node->Data )->inPack;
                lblExtract->Enabled = ((CGameObject*)Node->Data )->inPack;    
                currentDriver->viewFile( *((CGameObject*)Node->Data ) );
        }
}
//---------------------------------------------------------------------------


void __fastcall TfrmMain::FormCreate(TObject *Sender)
{
        imgImage->Picture->Bitmap->PixelFormat = pf24bit;
        imgImage->Picture->Bitmap->Canvas->Font->Name = "Arial";
        imgImage->Picture->Bitmap->Canvas->Font->Size = 7;
        imgImage->Picture->Bitmap->Canvas->Font->Pitch = fpFixed;
        for (int i = 0; i < driverCount; i++)
        {
                if (i == driverCount - 2)
                {
                        TMenuItem * menuBreak= new TMenuItem(frmMain);
                        menuBreak->Caption = "-";
                        popGame->Items->Add(menuBreak);
                }

                TMenuItem * menuItem = new TMenuItem(frmMain);
                menuItem->Caption = drivers[i]->getName();
                menuItem->Tag = i;
                //menuItem->OnClick = CosmosCosmicAdventure1Click;

                TMenuItem * openFile = new TMenuItem(frmMain);
                openFile->Caption = "Open file";
                openFile->OnClick = openFileClick;
                openFile->Tag = i;

                TMenuItem * openDir = new TMenuItem(frmMain);
                openDir->Caption = "Open directory";
                openDir->OnClick = openDirClick;
                openDir->Tag = i;

                menuItem->Add(openFile);
                menuItem->Add(openDir);

                popGame->Items->Add(menuItem);
        }
        IWombatGame::createCrashPalette();
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::btnSaveImageClick(TObject *Sender)
{
        if (svpSave->Execute())
        {
                imgImage->Picture->Bitmap->Width = bitmapSize.x;
                imgImage->Picture->Bitmap->Height = bitmapSize.y;
                imgImage->Picture->Bitmap->SaveToFile(svpSave->FileName);
        }
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::spnPlanesChange(TObject *Sender)
{
        if (currentDriver && trvGame->Selected && trvGame->Selected->Data)
                currentDriver->viewFile( *((CGameObject*)trvGame->Selected->Data ) );
}
//---------------------------------------------------------------------------


void __fastcall TfrmMain::btnPlayPCSoundClick(TObject *Sender)
{
        if (isSound)
        {
                if (lstPCSound->ItemIndex != -1)
                        playSound(lstPCSound->ItemIndex, true);
        } //play sound
        else //assume midi for now
        {
                /*HMIDISTRM stream;
                unsigned long deviceID = 0;
                midiStreamOpen(&stream, &deviceID,  1, NULL, NULL, CALLBACK_NULL);*/
                ofstream fileout((ExtractFilePath(ParamStr(0)) + "ttt.y654.mid").c_str(), ios::out | ios::binary);
                fileout.write(currentData, currentDataSize);
                fileout.close();
                medMedia->FileName = ExtractFilePath(ParamStr(0)) + "ttt.y654.mid";
                medMedia->Notify = true;
                medMedia->Open();
                medMedia->Play();  
        }

}
//---------------------------------------------------------------------------


void __fastcall TfrmMain::FormClose(TObject *Sender, TCloseAction &Action)
{
        DeleteFile(ExtractFilePath(ParamStr(0)) + "ttt.y654.mid");
        cleanUpSound;
        clearTreeView();
        for (int i = 0; i < driverCount; i++)
                delete drivers[i];
        if (currentData)
                delete [] currentData;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::cSpinImageUpClick(TObject *Sender)
{
        if (imgImage->Top < 0)
                imgImage->Top += 10;

}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::cSpinImageDownClick(TObject *Sender)
{
        if (imgImage->Height + imgImage->Top > pnlMain->Height)
                imgImage->Top -= 10;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::btnViewLevelClick(TObject *Sender)
{
        levelDriver = currentDriver;
        levelOffset = Point(0, 0);
        currentDriver->initLevel( *((CGameObject*)trvGame->Selected->Data ) );
        frmLevelViewer->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::spdExtractClick(TObject *Sender)
{
        if (svdSave->Execute())
        {
                ofstream file(svdSave->FileName.c_str(), ios::out | ios::binary);
                file.write(currentData, currentDataSize);
        }        
}
//---------------------------------------------------------------------------

