//---------------------------------------------------------------------------


#pragma hdrstop

#include "hocus.h"

using namespace std;

TRGB hocusPalette[256];
bool hocusPalLoaded = false;

class CHocusSpriteHeader {
        unsigned int offset;
        char name[13]; //use 12
};

AnsiString CWGame_Hocus::getName()
{
        return "Hocus Pocus";
}

AnsiString CWGame_Hocus::getFileExtensions()
{
        return "*.dat*";
}

CGameObject CWGame_Hocus::startUnpack(AnsiString fileName)
{
        lastUnpackAttempt.open(fileName.c_str(), ios::in | ios::binary);
        lastUnpackName = fileName;
        exeFile.open((ExtractFilePath(fileName) + "hocus.exe").c_str(), ios::in | ios::binary);

        exeFile.seekg(0, ios::end);
        unsigned size = exeFile.tellg();

        if (size < 200000)
                 exeFile.seekg(0x1EEB4);
        else
                exeFile.seekg(0x1AD74);
        currentFile = 1;
        oldValue = 0;
        return nextUnpack();
}

CGameObject CWGame_Hocus::nextUnpack()
{
        unsigned int offset, length;

        CGameObject result;
        result.inPack = true;

        exeFile.read((char*)&offset, sizeof(int));
        exeFile.read((char*)&length, sizeof(int));

        if (offset < oldValue)
        {
                lastUnpackAttempt.close();
                exeFile.close();
                result.objectType = egoNone;
                return result;
        }

        result.objectName = IntToStr(currentFile);
        result.extraData = currentFile++;
        result.positionInFile = offset;
        result.objectSize = length;
        result.fileName = lastUnpackName;

        result.objectType = processFile(result).objectType;

        result.objectName = result.objectName +  "(" + IntToStr(length) + ")";

        oldValue = offset;

        return result;
}

CGameObject CWGame_Hocus::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName.LowerCase();
        result.objectName = object.objectName;

     //   AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (object.objectName == "hocus.dat")
                result.objectType = egoPacked;
        else
        if (object.inPack)
        {
                if ((object.extraData > 598) && (object.extraData < 611))
                        result.objectType = egoMusic;
                else
                if ((object.extraData > 120) && (object.extraData < 131) && (object.extraData != 122))
                        result.objectType = egoSprite;
                else
                if (object.objectSize == 4000)
                        result.objectType = egoDOSScreen;
                else
                {
                        unsigned short bob;
                        lastUnpackAttempt.seekg(object.positionInFile);
                        lastUnpackAttempt.read((char*)&bob, sizeof(bob));
                        if (bob == 1290)
                                result.objectType = egoImage;
                        if (bob == 29251)
                                result.objectType = egoSound;
                }
        }
        return result;
}

void CWGame_Hocus::drawImage(char *data, CGameObject object, TImage *image)
{
        if (!hocusPalLoaded)
        {
                CGameObject palInfo = findObject("112(25608)", 112);
                char *palData;

                unpackFileFromPack(palInfo,palData);

                int offset = palInfo.objectSize - 769;

                for (int i = 0; i < 256; i++)
                        hocusPalette[i] = TRGB(palData[offset + (i * 3 + 1)], palData[offset + (i * 3 + 2)], palData[offset + (i * 3)]);

                delete [] palData;

                hocusPalLoaded = true;
        }

        switch (object.objectType){
                case egoImage: drawPCX(data, object.objectSize); break;
                case egoSprite: if (object.extraData == 130)
                                        break;
                                else
                                        drawVGAInterlaced(data, 4, 4, Point( ((unsigned short *)data)[0], ((unsigned short *)data)[1]), Point(0, 0), hocusPalette);
                                        break;
        }
}


//---------------------------------------------------------------------------

#pragma package(smart_init)
