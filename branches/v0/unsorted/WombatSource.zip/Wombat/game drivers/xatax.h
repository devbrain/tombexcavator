//---------------------------------------------------------------------------

#ifndef xataxH
#define xataxH

#include "pixelpainter.h"

struct CWGame_Xatax: public CWExtractor_PixelPainter {
        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);


};
//---------------------------------------------------------------------------
#endif
