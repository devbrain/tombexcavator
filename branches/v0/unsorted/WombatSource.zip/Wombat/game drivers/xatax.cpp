//---------------------------------------------------------------------------


#pragma hdrstop

#include "xatax.h"

#include <sysutils.hpp>

#include "main.h"

AnsiString CWGame_Xatax::getName()
{
       // return "Xatax";
       return "PixelPainter games";
}

AnsiString CWGame_Xatax::getFileExtensions()
{
        return "*.res";
}

CGameObject CWGame_Xatax::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (extension == ".res")
                result.objectType = egoPacked;
        else
        if (extension == ".txt")
                result.objectType = egoText;
        else
        if ((extension == ".spf") || (extension == ".mpf") || (extension == ".ani"))
                result.objectType = egoImage;
        else
        if (extension == ".ftf")
                result.objectType = egoMusic;
        return result;
}

void CWGame_Xatax::drawImage(char *data, CGameObject object, TImage *image)
{
        /*TRGB crashPalette[256];
        for (int i = 0; i < 256; i++)
                crashPalette[i] = TRGB(random(256), random(256), random(256));
        drawVGAImage(data, 0, Point(frmMain->spn2->Value, frmMain->spnPlanes->Value), Point(0, 0), crashPalette);*/
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
