//---------------------------------------------------------------------------

#ifndef secretagentH
#define secretagentH

#include "wombatCommon.h"

struct CWGame_SecretAgent: public IWombatGame {
        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "Using some code from:\nFrenkel Smeijers (www.sfprod.tk)";};
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);

        virtual CGameObject startUnpack(AnsiString fileName){CGameObject o; return o;};
        virtual CGameObject nextUnpack(){CGameObject o; return o;};
        virtual int unpackFileFromPack(CGameObject object, char* &buffer);
        private:
        void decryptGFX(unsigned char* buffer, int start, int end);
};
//---------------------------------------------------------------------------
#endif
