//---------------------------------------------------------------------------

#ifndef cosmoH
#define cosmoH

#include "replogle.h"

struct CWGame_Cosmo: public CWExtractor_Replogle {
        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "Using some code from:\nFrenkel Smeijers (www.sfprod.tk)";};
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);

        virtual ESoundType soundType(CGameObject object) {return wsndSnd;};

};
//---------------------------------------------------------------------------
#endif
