//---------------------------------------------------------------------------

#ifndef clyde1H
#define clyde1H

#include "wombatCommon.h"

struct CWGame_Clyde1: public IWombatGame {
        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "Using some code from:\nFrenkel Smeijers (www.sfprod.tk)";};
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);

        virtual CGameObject startUnpack(AnsiString fileName){CGameObject o; return o;};
        virtual CGameObject nextUnpack(){CGameObject o; return o;};
        virtual int unpackFileFromPack(CGameObject object, char* &buffer); 
};
//---------------------------------------------------------------------------
#endif
