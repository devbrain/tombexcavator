//---------------------------------------------------------------------------


#pragma hdrstop

#include "crystalcaves.h"

#include <iostream>

using namespace std;

AnsiString CWGame_CrystalCaves::getName()
{
        return "Crystal Caves";
}

AnsiString CWGame_CrystalCaves::getFileExtensions()
{
        return "*.mni;*.gfx;*.cdt;*.ttl;*.end;*.apg;*.snd";
}

CGameObject CWGame_CrystalCaves::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        ifstream file(object.fileName.c_str(), ios::in | ios::binary);
        file.seekg(0, ios::end);
        result.objectSize = file.tellg();
        file.close();

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (extension == ".mni")
                result.objectType = egoSprite;
        else
        if (extension == ".gfx")
                result.objectType = egoBackTile;
        else
        if ((extension == ".cdt") || (extension == ".ttl") || (extension == ".end") || (extension == ".apg"))
                result.objectType = egoFullscreen;
        else
        if (extension == ".snd")
                result.objectType = egoSound;
        return result;
}

void CWGame_CrystalCaves::drawImage(char *data, CGameObject object, TImage *image)
{
        switch (object.objectType){
        case egoSprite: drawEGATiles(data, 0, object.objectSize, true, Point(8, 8), Point(0, 0), 320, true, edpHeight, defaultPalette);
                        break;
        case egoBackTile: for (int i = 0; i < 23; i++)
                                drawEGATiles(data, (i * 8003) + 3, ((i + 1) * 8003), true, Point(16, 16), Point(0, i*32), 400, true, edpWidth, defaultPalette);
                          break;
        case egoFullscreen: drawPCX(data, object.objectSize);
                            break;
        }

}

int CWGame_CrystalCaves::unpackFileFromPack(CGameObject object, char* &buffer)
{
        return 0;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
