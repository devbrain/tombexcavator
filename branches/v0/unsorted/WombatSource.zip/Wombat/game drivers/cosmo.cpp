//---------------------------------------------------------------------------


#pragma hdrstop

#include "cosmo.h"
#include <sysutils.hpp>

struct CCosmoSprite {
        unsigned short height, width;
        unsigned int offset;
};

AnsiString CWGame_Cosmo::getName()
{
        return "Cosmo's Cosmic Adventure";
}

AnsiString CWGame_Cosmo::getFileExtensions()
{
        return "*.vol;*.stn";
}

CGameObject CWGame_Cosmo::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName.LowerCase();
        result.objectName = object.objectName;

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if ((extension == ".stn") || (extension == ".vol"))
                result.objectType = egoPacked;
        else
        if ((object.objectName == "fonts.mni") || (object.objectName == "masktile.mni"))
                result.objectType = egoForeTile;
        else
        if (object.objectName.SubString(1, 6) == "sounds")
                result.objectType = egoSound;
        else   
        if (object.objectSize == 32000)
                result.objectType = egoFullscreen;
        else
        if ((object.objectName.SubString(1, 2) == "bd") || (object.objectName == "status.mni") || (object.objectName == "tiles.mni"))
                result.objectType = egoBackTile;
        else
        if ((object.objectSize > 64999) && (object.objectSize < 70000) && ((char)object.objectName[1] >= 'a') && ((char)object.objectName[1] <= 'c'))
                result.objectType = egoLevel;
        else
        if ((object.objectName == "actors.mni") || (object.objectName == "players.mni") || (object.objectName == "cartoon.mni"))
                result.objectType = egoSprite;
        else
        if (object.objectName[1] == 'm')
                result.objectType = egoMusic;
        else
        if (object.objectSize == 4000)
                result.objectType = egoDOSScreen;
        return result;
}

void CWGame_Cosmo::drawImage(char *data, CGameObject object, TImage *image)
{
        CGameObject spriteInfo;
        int spriteOffset = 2;
        TPoint drawOffset = Point(0, 0);
        char * spriteData;
        CCosmoSprite * sprite;

        int maxHeight = 0;
        int dataSubtract = 0;

        switch (object.objectType){
                case egoFullscreen: drawEGANoProcess(data, 0, 4, Point(320, 200), Point(0, 0), false, edpPlane, defaultPalette); break;
                case egoBackTile: if (object.objectName == "status.mni")
                                        drawEGATiles(data, 0, object.objectSize, false, Point(8, 8), Point(0, 0), 304, false, edpHeight, defaultPalette);
                                  else
                                        drawEGATiles(data, 0, object.objectSize, false, Point(8, 8), Point(0, 0), 320, false, edpHeight, defaultPalette); break;
                case egoForeTile: drawEGATiles(data, 0, object.objectSize, true, Point(8, 8), Point(0, 0), 320, (object.objectName == "fonts.mni"), edpHeight, defaultPalette); break;
                case egoSprite: if (object.objectName == "actors.mni")
                                {
                                        spriteOffset = 534;
                                        spriteInfo = findObject("actrinfo.mni", 0);
                                }
                                else
                                if (object.objectName == "players.mni")
                                         spriteInfo = findObject("plyrinfo.mni", 0);
                                else
                                         spriteInfo = findObject("cartinfo.mni", 0);
                                spriteInfo.positionInFile += spriteOffset;
                                spriteInfo.objectSize -= spriteOffset;
                                unpackFileFromPack(spriteInfo, spriteData);

                                unsigned currentCounter = 0;
                                while (currentCounter * 8 < spriteInfo.objectSize)
                                {
                                        if (drawOffset.x + sprite->width * 8 >= image->Picture->Bitmap->Width)
                                        {
                                                drawOffset.x = 0;
                                                drawOffset.y += maxHeight + 2;
                                                maxHeight = 0;
                                        }

                                        if ((currentCounter == 210) || (currentCounter == 359))
                                                dataSubtract += 1;

                                        sprite = &(((CCosmoSprite *)spriteData)[currentCounter]);
                                        drawEGATiles(data, sprite->offset - dataSubtract, sprite->offset - dataSubtract + (40 * sprite->width * sprite->height), true, Point(8, 8), drawOffset, sprite->width * 8, false, edpHeight, defaultPalette);
                                        drawOffset.x += (sprite->width * 8) + 2;
                                        if (sprite->height * 8 > maxHeight)
                                        maxHeight = sprite->height * 8; 
                                        currentCounter++;
                                }

                                delete [] spriteData;
                                break;

        }
        drawPalette(defaultPalette, 16);
}


//---------------------------------------------------------------------------

#pragma package(smart_init)
