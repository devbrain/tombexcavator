void deLZWGerald(void* _src, void *_dst, int dstSize);
 