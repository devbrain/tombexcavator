//---------------------------------------------------------------------------

#ifndef mbashH
#define mbashH

#include "wombatCommon.h"

struct CWGame_MonsterBash: public IWombatGame {
        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "Some issues here, mainly to do with sprites";};
        virtual CGameObject processFile(CGameObject object);
        virtual CGameObject startUnpack(AnsiString fileName);
        virtual CGameObject nextUnpack();
        virtual void drawImage(char *data, CGameObject object, TImage *image);
        virtual int unpackFileFromPack(CGameObject object, char* &buffer);

        virtual void initLevel(CGameObject object);
        virtual void drawLevel(TPoint offset);

        virtual ESoundType soundType(CGameObject object) {return wsndSnd;};
        virtual bool canViewLevel(){return true;};

        virtual int getLevelWidth() {return levelWidth;};
        virtual int getLevelHeight() {return levelHeight;};

        CWGame_MonsterBash();
        ~CWGame_MonsterBash();

private:
       // int unLZW(char * source, char * dest, int sizeSource, int sizeDest);
        void drawSprite(char *data, unsigned dataSize, TImage * image);

        std::ifstream lastUnpackAttempt;
        AnsiString lastUnpackName;

        Graphics::TBitmap *backgroundTiles, *foregroundTiles, *foregroundMask, *bonTiles, *bonMask;
        char *levelBackData, *levelForeData, *levelData;

        int levelWidth, levelHeight;

        void drawBack(TPoint offset);
        void drawForeground(TPoint offset);
        void drawProperties(TPoint offset);
};
//---------------------------------------------------------------------------
#endif
