//---------------------------------------------------------------------------

#ifndef picklewH
#define picklewH

#include "wombatCommon.h"

struct CWGame_PickleWars: public CSimpleExtractor {
        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "Using some code from:\nFrenkel Smeijers (www.sfprod.tk)";};
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);

        virtual CGameObject startUnpack(AnsiString fileName);
        virtual CGameObject nextUnpack(); 
};
//---------------------------------------------------------------------------
#endif
