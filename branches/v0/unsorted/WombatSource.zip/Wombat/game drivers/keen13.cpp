//---------------------------------------------------------------------------


#pragma hdrstop

#include "keen13.h"
#include <iostream>
#include "lzw.h"

using namespace std;

struct CEGAHeader{
   unsigned int LatchPlaneSize;		//Size of one plane of latch data
   unsigned int SpritePlaneSize;	//Size of one plane of sprite data
   unsigned int OffBitmapTable;		//Offset in EGAHEAD to bitmap table
   unsigned int OffSpriteTable;		//Offset in EGAHEAD to sprite table
   unsigned short Num8Tiles;		//Number of 8x8 tiles
   unsigned int Off8Tiles;		//Offset of 8x8 tiles (relative to plane data)
   unsigned short Num32Tiles;		//Number of 32x32 tiles (always 0)
   unsigned int Off32Tiles;		        //Offset of 32x32 tiles (relative to plane data)
   unsigned short Num16Tiles;		//Number of 16x16 tiles
   unsigned int Off16Tiles;		        //Offset of 16x16 tiles (relative to plane data)
   unsigned short NumBitmaps;		//Number of bitmaps in table
   unsigned int OffBitmaps;		        //Offset of bitmaps (relative to plane data)
   unsigned short NumSprites;		//Number of sprites
   unsigned int OffSprites;		        //Offset of sprites (relative to plane data)
   unsigned short Compressed;	        //(Keen 1 only) Nonzero: LZ compressed data
};

CEGAHeader EGAHeader;

AnsiString CWGame_Keen13::getName()
{
        return "Commander Keen 1-3";
}

AnsiString CWGame_Keen13::getFileExtensions()
{
        return "*.ck1;*.ck2;*.ck3";
}

CGameObject CWGame_Keen13::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        ifstream file(object.fileName.c_str(), ios::in | ios::binary);
        file.seekg(0, ios::end);
        result.objectSize = file.tellg();
        file.seekg(0);


        if (object.objectName.SubString(1, 5) == "level")
                result.objectType = egoLevel;
        else
        if (object.objectName.SubString(1, 8) == "egasprit")
                result.objectType = egoSprite;
        else
        if (object.objectName.SubString(1, 8) == "egalatch")
                result.objectType = egoBackTile;
        if (object.objectName.SubString(1, 7) == "egahead")
        {
                file.read((char*)&EGAHeader, 16);
                file.read((char*)&EGAHeader.Num8Tiles, sizeof(short));
                file.read((char*)&EGAHeader.Off8Tiles, sizeof(int));
                file.read((char*)&EGAHeader.Num32Tiles, sizeof(short));
                file.read((char*)&EGAHeader.Off32Tiles, sizeof(int));

                file.read((char*)&EGAHeader.Num16Tiles, sizeof(short));
                file.read((char*)&EGAHeader.Off16Tiles, sizeof(int));
                file.read((char*)&EGAHeader.NumBitmaps, sizeof(short));
                file.read((char*)&EGAHeader.OffBitmaps, sizeof(int));

                file.read((char*)&EGAHeader.NumSprites, sizeof(short));
                file.read((char*)&EGAHeader.OffSprites, sizeof(int));

                file.read((char*)&EGAHeader.Compressed, sizeof(short));
        }
        file.close();

        return result;
}

void CWGame_Keen13::drawImage(char *data, CGameObject object, TImage *image)
{
        char * copiedData;
        switch (object.objectType)
        {
                case egoBackTile:       if (!EGAHeader.Compressed)
                                                copiedData = new char[object.objectSize];
                                        else
                                        {
                                                copiedData = new char[object.objectSize * 5];
                                                unLZW(data, copiedData, object.objectSize, object.objectSize * 5, 9, 12, false, 258);
                                        }

                                        for (int p = 0; p < 4; p++)
                                                for (int i = 0; i < EGAHeader.Num8Tiles; i++)
                                                        memcpy((void*)&copiedData[(i * 32) + p * 8], (void*)&data[p * EGAHeader.LatchPlaneSize + EGAHeader.Off8Tiles + i * 8], 8);
                                        drawEGATiles(copiedData, 0, EGAHeader.Num8Tiles * 32, false, Point(8, 8), Point(0, 0), 320, true, edpPlane, defaultPalette);

                                        for (int p = 0; p < 4; p++)
                                                for (int i = 0; i < EGAHeader.Num16Tiles; i++)
                                                        memcpy((void*)&copiedData[(i * 128) + p * 32], (void*)&data[p * EGAHeader.LatchPlaneSize + EGAHeader.Off16Tiles + i * 32], 32);
                                        drawEGATiles(copiedData, 0, EGAHeader.Num16Tiles * 128, false, Point(16, 16), Point(0, ((EGAHeader.Num8Tiles * 8) / 320) * 8), 208, true, edpPlane, defaultPalette);

                                        delete [] copiedData;
        }
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
