//---------------------------------------------------------------------------

#ifndef wackywH
#define wackywH
#include "wombatCommon.h"

struct CWGame_WackyWheels: public CSimpleExtractor {
        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "Using some code from:\nFrenkel Smeijers (www.sfprod.tk)";};
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);
        virtual EMusicType musicType(CGameObject object);

        virtual CGameObject startUnpack(AnsiString fileName);
        virtual CGameObject nextUnpack();

        unsigned short currentFile, fileCount;
};
//---------------------------------------------------------------------------
#endif
