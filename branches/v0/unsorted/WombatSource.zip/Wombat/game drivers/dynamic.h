//---------------------------------------------------------------------------

#ifndef dynamicH
#define dynamicH

#include "wombatCommon.h"

struct CWGame_Dynamic: public IWombatGame {
        virtual AnsiString getName(){return "Unknown EGA image";};
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "";};
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);

        virtual CGameObject startUnpack(AnsiString fileName){CGameObject o; return o;};
        virtual CGameObject nextUnpack(){CGameObject o; return o;};
        virtual int unpackFileFromPack(CGameObject object, char* &buffer){return 0;}; 
};
//---------------------------------------------------------------------------
#endif
