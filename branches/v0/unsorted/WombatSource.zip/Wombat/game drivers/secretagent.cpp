//---------------------------------------------------------------------------


#pragma hdrstop

#include "secretagent.h"

#include <iostream>
#include <math.hpp>

int XORTable[28] = {0x43, 0x6F, 0x70, 0x79, 0x72, 0x69, 0x67, 0x68, 0x74, 0x20, 0x31, 0x39, 0x39, 0x31,
                    0x20, 0x50, 0x65, 0x64, 0x65, 0x72, 0x20, 0x4A, 0x75, 0x6E, 0x67, 0x63, 0x6B, 0x0};

using namespace std;

AnsiString CWGame_SecretAgent::getName()
{
        return "Secret Agent";
}

AnsiString CWGame_SecretAgent::getFileExtensions()
{
        return "*.gfx;*.crd;*.ttl;*.end;*.apo;*.snd";
}

void CWGame_SecretAgent::decryptGFX(unsigned char* buffer, int start, int end)
{
        unsigned char c;

        for (int i = start; i < end; i++)
        {
                c = buffer[i];
                int j = 0;
 
                for (int k = 0; k < 8; k++)
                        if ( ( (unsigned char) Power(2, k) ) & c)
                                j = j | ( (unsigned char) Power(2, (k ^ 7) ) );
                buffer[i] = j ^ XORTable[i % 28];

        }
}

CGameObject CWGame_SecretAgent::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        ifstream file(object.fileName.c_str(), ios::in | ios::binary);
        file.seekg(0, ios::end);
        result.objectSize = file.tellg();
        file.close();

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (object.objectName.SubString(object.objectName.Length()-4, 5) == "1.gfx")
                result.objectType = egoBackTile;
        else
        if ((extension == ".crd") || (extension == ".ttl") || (extension == ".end") || (extension == ".apo"))
                result.objectType = egoFullscreen;
        if (extension == ".snd")
                result.objectType = egoSound;
        return result;
}

void CWGame_SecretAgent::drawImage(char *data, CGameObject object, TImage *image)
{
        switch (object.objectType){
        case egoSprite: drawEGATiles(data, 0, object.objectSize, true, Point(8, 8), Point(0, 0), 320, true, edpHeight, defaultPalette);
                        break;
        case egoBackTile: for (int i = 0; i < 16; i++)
                          {
                                decryptGFX((unsigned char *)data, (i * 8064), ((i + 1) * 8064));
                                drawEGATiles(data, (i * 8064) + 3, ((i + 1) * 8064), true, Point(16, 16), Point(0, i*32), 400, true, edpWidth, defaultPalette);
                          }
                          break;
        case egoFullscreen: drawPCX(data, object.objectSize);
                            break;
        }

}

int CWGame_SecretAgent::unpackFileFromPack(CGameObject object, char* &buffer)
{
        return 0;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
