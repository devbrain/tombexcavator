//---------------------------------------------------------------------------

#ifndef crystalcavesH
#define crystalcavesH

#include "wombatCommon.h"

struct CWGame_CrystalCaves: public IWombatGame {
        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "Using some code from:\nFrenkel Smeijers (www.sfprod.tk)";};
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);

        //files are not packed in crystal caves, afaik.
        virtual CGameObject startUnpack(AnsiString fileName){CGameObject o; return o;};
        virtual CGameObject nextUnpack(){CGameObject o; return o;};
        virtual int unpackFileFromPack(CGameObject object, char* &buffer); 
};
//---------------------------------------------------------------------------
#endif
