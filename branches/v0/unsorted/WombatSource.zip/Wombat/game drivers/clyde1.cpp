//---------------------------------------------------------------------------


#pragma hdrstop

#include "clyde1.h"

#include <iostream>

#include "main.h"

using namespace std;

AnsiString CWGame_Clyde1::getName()
{
        return "Clyde 1";
}

AnsiString CWGame_Clyde1::getFileExtensions()
{
        return "*.ca1;*.ca2";
}

CGameObject CWGame_Clyde1::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        ifstream file(object.fileName.c_str(), ios::in | ios::binary);
        file.seekg(0, ios::end);
        result.objectSize = file.tellg();
        file.close();

        AnsiString strippedName = object.objectName.SubString(1, object.objectName.Length()-4);

        if (strippedName == "volume_1")
                result.objectType = egoImage;
        if (strippedName == "volume_2")
                result.objectType = egoSprite;

        return result;
}

//TODO: put this in CWGame_Clyde1, if Clyde 2 does not work the same way.

void movePlanes(char * dest, char * source, int dataStart, int spriteCount)
{
        short oneItemSize = 480;
        short threePlaneSize = 384;

        for (int i = 0; i < spriteCount; i++) //copy planes for 3 stars
        {
                memcpy((void*)&dest[dataStart + (oneItemSize * i) + 96], (void*)&source[dataStart + (threePlaneSize * i)], threePlaneSize);
                memcpy((void*)&dest[dataStart + oneItemSize * i],        (void*)&source[dataStart + (spriteCount * threePlaneSize) + (i * 96)], 96);
        }
}

void CWGame_Clyde1::drawImage(char *data, CGameObject object, TImage *image)
{
        char * clydeSprite;
        unsigned currentFrame = 0;
        switch (object.objectType){
        case egoSprite: clydeSprite = new char[object.objectSize];
                        movePlanes(clydeSprite, data, 0, 3);
                        movePlanes(clydeSprite, data, 1440, 32);
                        movePlanes(clydeSprite, data, 16800, 6);
                        movePlanes(clydeSprite, data, 19680, 12);
                        drawEGATiles(clydeSprite, 0, 25440, true, Point(24, 32), Point(0, 0), 320, true, edpPlane, defaultPalette);
                        movePlanes(clydeSprite, data, 25440, 1);
                        drawEGANoProcess(data, 25440, 5, TPoint(48, 16), Point(0, 160), true, edpPlane, defaultPalette);
                        delete [] clydeSprite;

                        /*for (int i = 0; i < 3; i++) //trans for 3 stars
                                drawEGANoProcess(data, 1152 + (i * 96), 1, TPoint(24, 32), Point(72 + (i * 24), 0), true, edpPlane, defaultPalette);
                        drawEGATiles(data, 1440, 13728, false, Point(24, 32), Point(0, 32), 320, true, edpPlane, defaultPalette);
                        for (int i = 0; i < 7; i++)  //trans for char
                                drawEGANoProcess(data, 13728 + (i * 96), 1, TPoint(24, 32), Point(144 + (i * 24), 96), true, edpPlane, defaultPalette);*/
                        image->Canvas->TextOut(0, 176, "[UNDECIPHERED DATA]");
                        break;
        case egoImage:  int tilesToWidth = 40;

                        while (currentFrame < 90)
                        {
                                drawEGANoProcess(data, currentFrame * 8, 1, TPoint(8, 8), Point(((currentFrame % tilesToWidth) * 8), ((currentFrame  / tilesToWidth) * 8)), true, edpPlane, defaultPalette);
                                currentFrame++;
                        }
                        image->Canvas->TextOut(0, 24, "[UNDECIPHERED DATA]");
                        break;
        }


}

int CWGame_Clyde1::unpackFileFromPack(CGameObject object, char* &buffer)
{
        return 0;
}


//---------------------------------------------------------------------------

#pragma package(smart_init)
