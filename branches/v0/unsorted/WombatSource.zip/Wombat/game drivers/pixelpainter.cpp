//---------------------------------------------------------------------------


#pragma hdrstop

#include "pixelpainter.h"
#include <iostream>

using namespace std;

struct CPixelPainterHeader{
        char cFilename[13];
        unsigned nOffset;
        unsigned nLength;
        char unknown[2];
};

CGameObject CWExtractor_PixelPainter::startUnpack(AnsiString fileName)
{
        lastUnpackAttempt.open(fileName.c_str(), ios::in | ios::binary);
        lastUnpackName = fileName;
        char unknown;
        lastUnpackAttempt.read((char*)&fileCount, sizeof(unsigned short));
        lastUnpackAttempt.read(&unknown, sizeof(char));
        currentFile = 0;
        return nextUnpack();
}

CGameObject CWExtractor_PixelPainter::nextUnpack()
{
        CPixelPainterHeader header;

        CGameObject result;
        result.inPack = true;

        if (currentFile == fileCount)
        {
                lastUnpackAttempt.close();
                result.objectType = egoNone;
                return result;
        }


        lastUnpackAttempt.read((char*)&header.cFilename, 12);
        header.cFilename[12] = '\0';
        lastUnpackAttempt.read((char*)&header.nOffset, sizeof(unsigned));
        lastUnpackAttempt.read((char*)&header.nLength, sizeof(unsigned));
        lastUnpackAttempt.read((char*)&header.unknown, 2);


        result.objectName = ((AnsiString)header.cFilename).LowerCase();
        result.positionInFile = header.nOffset;
        result.objectSize = header.nLength;
        result.fileName = lastUnpackName;

        result.objectType = processFile(result).objectType;

        result.objectName = result.objectName +  "(" + IntToStr(header.nLength) + ")";

        currentFile++;

        return result;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
