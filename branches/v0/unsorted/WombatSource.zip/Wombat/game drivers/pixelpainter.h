//---------------------------------------------------------------------------

#ifndef pixelpainterH
#define pixelpainterH

#include "wombatCommon.h"

struct CWExtractor_PixelPainter: public CSimpleExtractor {
        virtual CGameObject startUnpack(AnsiString fileName);
        virtual AnsiString getCredits() {return "Using some code from:\nFrenkel Smeijers (www.sfprod.tk)";};
        virtual CGameObject nextUnpack();

        unsigned short currentFile, fileCount;
};
//---------------------------------------------------------------------------
#endif
