//---------------------------------------------------------------------------


#pragma hdrstop

#include "cannon.h"

#include <iostream>

using namespace std;

struct CCannonHeader{
        char cFilename[13];
        unsigned long nOffset;
        unsigned long nLength;
};

CGameObject CWGame_Cannon::startUnpack(AnsiString fileName)
{
        lastUnpackAttempt.open(fileName.c_str(), ios::in | ios::binary);
        lastUnpackName = fileName;
        lastUnpackAttempt.read((char*)&dataStart, sizeof(unsigned long)); 
        return nextUnpack();
}

CGameObject CWGame_Cannon::nextUnpack()
{
        CCannonHeader header;

        CGameObject result;
        result.inPack = true;

        if ((unsigned)lastUnpackAttempt.tellg() >= dataStart)
        {
                lastUnpackAttempt.close();
                result.objectType = egoNone;
                return result;
        }


        memset(header.cFilename, 0, 13);
        char c;
        lastUnpackAttempt.read(&c, sizeof(char)); //read filename length

        lastUnpackAttempt.read((char*)&header.cFilename, c);
        lastUnpackAttempt.read((char*)&header.nOffset, sizeof(unsigned long));
        lastUnpackAttempt.read((char*)&header.nLength, sizeof(unsigned long)); 

        result.objectName = ((AnsiString)header.cFilename).LowerCase();
        result.positionInFile = header.nOffset;
        result.objectSize = header.nLength;
        result.fileName = lastUnpackName;

        result.objectType = processFile(result).objectType;

        result.objectName = result.objectName +  " - " + IntToStr(header.nLength) + "b";

        return result;
}

AnsiString CWGame_Cannon::getName()
{
        return "Cannon Fodder";
}

AnsiString CWGame_Cannon::getFileExtensions()
{
        return "*.dat";
}

CGameObject CWGame_Cannon::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (object.objectName == "cf_eng.dat")
                result.objectType = egoPacked;
        /*else
        if (extension == ".mid")
                result.objectType = egoMusic;
        else
        if (extension == ".voc")
                result.objectType = egoSound;
        else
        if (extension == ".pcx")
                result.objectType = egoImage;
        else
        if (object.objectName.SubString(object.objectName.Length()-2, 3) == ".sp")
                result.objectType = egoSprite;   */
        return result;
}

void CWGame_Cannon::drawImage(char *data, CGameObject object, TImage *image)
{
}



//---------------------------------------------------------------------------

#pragma package(smart_init)
