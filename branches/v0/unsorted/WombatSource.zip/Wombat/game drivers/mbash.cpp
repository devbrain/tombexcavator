//---------------------------------------------------------------------------
// The monster bash / scubaventure driver.  Still very buggy and preliminary
//
// Michael Szewczyk, 2004
//---------------------------------------------------------------------------

#pragma hdrstop

#include "mbash.h"
#include <iostream>
#include <sysutils.hpp>
#include <math.h>
#include "lzw.h"
#include "deBash.h"

#include "levelViewer.h"

//TEMP!!!!
#include "main.h"

/*  SPECIAL TILE ATTRIBUTES, BIT 0 IS RIGHT-MOST:
0 (1):   right wall
1 (2):   left wall
2 (4):   floor
3 (8):   ceiling
4 (16):  special property
5 (32):  sloping tile
6 (64):  unknown, occurs at player start bash1.lvl1
7 (128): not found occuring */

using namespace std;

AnsiString friendlyNames[] = {"load list", "level-back", "level fore+on", "background", "foreground", "background-on", "sprite list", "actors", "DNO", "DNO", "DNO", "DNO", "backgr-lst?", "foregr-lst?", "14", "DNO", "backgr-on-lst?"};

TRGB MBashPalette[16] = {TRGB(0, 0, 0),    TRGB(0x54, 0x54, 0x54), TRGB(0xA8, 0, 0),    TRGB(0xFC, 0x54, 0x54), TRGB(0, 0xA8, 0),    TRGB(0x54, 0xFC, 0x54), TRGB(0xA0, 0x54, 0),    TRGB(0xFC, 0xFC, 0x54),
                         TRGB(0, 0, 0xA8), TRGB(0x54, 0x54, 0xFC), TRGB(0xA8, 0, 0xA8), TRGB(0xFC, 0x54, 0xFC), TRGB(0, 0xA8, 0xA8), TRGB(0x54, 0xFC, 0xFC), TRGB(0xA8, 0xA8, 0xA8), TRGB(0xFC, 0xFC, 0xFC)};

struct MBashHeader
{
        unsigned short nType;
        unsigned short nSize;
        char cFilename[31];
        unsigned short nCompression;
};

struct MBashSprite {
        unsigned char firstFrame;
        char whoKnows[3];
        unsigned char height;
        unsigned char width;
        char whoKnows2[10];
};

AnsiString CWGame_MonsterBash::getName()
{
        return "Monster Bash/ScubaVenture";
}

AnsiString CWGame_MonsterBash::getFileExtensions()
{
        return "*.dat";
}

CGameObject CWGame_MonsterBash::processFile(CGameObject object)
{
        CGameObject result = object;
        result.objectType = egoOther;

        if (object.objectName.LowerCase().SubString(object.objectName.Length() - 3, 4) == ".dat")
        {
                result.objectType = egoPacked;
                result.positionInFile = 0;
                return result;
        }

        AnsiString extension = object.objectName.SubString(object.objectName.Length() - 3, 4);

        switch (object.extraData){
                case 64: result.objectType = egoSprite; break;
                case 32: if ((extension == ".txt") || (extension == ".diz"))
                                result.objectType = egoText;
                         else
                         if (extension == ".voc")
                                result.objectType = egoSound;
                         else
                         if (extension == ".imf")
                                result.objectType = egoMusic;
                         else
                                result.objectType = egoDOSScreen;
                         break;
                case 8:  result.objectType = egoSound; break;
                case 3:  result.objectType = egoBackTile; break;
                case 4:
                case 5:  result.objectType = egoForeTile; break;
                case 0:  result.objectType = egoLevel; break;
                case 1: case 2: case 6: case 7: case 12: case 13: case 14: case 15: case 16:
                         result.objectType = egoOther; /*result.objectName = result.objectName + "." + friendlyNames[object.extraData]*/;
                         break;}
        return result;
}

CGameObject CWGame_MonsterBash::startUnpack(AnsiString fileName)
{
        lastUnpackAttempt.open(fileName.c_str(), ios::in | ios::binary);
        lastUnpackName = fileName;
        return nextUnpack();
}

CGameObject CWGame_MonsterBash::nextUnpack()
{
        CGameObject result;
        result.objectType = egoNone;
        result.inPack = true;

        MBashHeader header;
        lastUnpackAttempt.read((char*)&header.nType, sizeof(unsigned short));
        lastUnpackAttempt.read((char*)&header.nSize, sizeof(unsigned short));
        lastUnpackAttempt.read((char*)&header.cFilename, 31);
        lastUnpackAttempt.read((char*)&header.nCompression, sizeof(unsigned short));

        if (lastUnpackAttempt.eof())
        {
                lastUnpackAttempt.close();
                return result;
        }

        result.positionInFile = lastUnpackAttempt.tellg() - 31 - (sizeof(unsigned short) * 3);  

        result.objectName = (AnsiString)header.cFilename;
        result.fileName = lastUnpackName;
        result.extraData = header.nType;
        if (header.nCompression == 0)
                result.objectSize = header.nSize;
        else
                result.objectSize = header.nCompression;

        result = processFile(result);

        lastUnpackAttempt.seekg(lastUnpackAttempt.tellg() + header.nSize);

        return result;
}

void CWGame_MonsterBash::drawSprite(char *data, unsigned dataSize, TImage * image)
{
        //mmoText->Lines->Clear();
        MBashSprite * spriteData = (MBashSprite*)data;

        unsigned eWidth;
        /*if (spriteData->width % 8 == 0)
                eWidth = spriteData->width;
        else
                eWidth = spriteData->width + 8 - (spriteData->width % 8); */

        unsigned eHeight /*= spriteData->height*/;

        //lblSprite->Caption = IntToStr(eWidth) + "x" + IntToStr(eHeight);

        int currentBit = -1;
        unsigned currentDat = 1;
        UCHAR fullDat = 0;
        unsigned maxHeight = 0;
        int currentFrame = 0;
        int drawLocationX = 0, drawLocationY = 0;
        unsigned ePlanes = frmMain->spnPlanes->Value;
        unsigned aTemp;

        //AnsiString debugText;

        char ** plane = new char*[ePlanes];

        while (currentDat < dataSize)
        {
                spriteData = (MBashSprite*)((void*)&data[currentDat - 1]);
                //debugText = (spriteData->firstFrame == 255)?"f,":"n,";
                //for (int i = 0; i < 3; i++)
                //        debugText = debugText + IntToStr((unsigned char)spriteData->whoKnows[i]) + ',';
                //debugText += "w" + IntToStr(spriteData->width);
                //debugText += ",h" + IntToStr(spriteData->height);
                //for (int i = 0; i < 10; i++)
                //        debugText = debugText + ',' + IntToStr((unsigned char)spriteData->whoKnows2[i]);

                //mmoText->Lines->Add(debugText);

                eHeight = spriteData->height;
                eWidth = spriteData->width;

                currentDat += 15;


                if (eHeight > maxHeight)
                        maxHeight = eHeight;

                if (spriteData->width % 8 != 0)
                        eWidth += 8 - (eWidth % 8);

                 for (unsigned plan = 0; plan < ePlanes; plan++)
                {
                        plane[plan] = new char[eWidth * eHeight];
                        memset(plane[plan], eWidth * eHeight, 0);
                }

                for (unsigned plan = 0; plan < ePlanes; plan++)
                {
                        for (unsigned j = 0; j < eHeight; j++)
                        {
                                for (unsigned i = 0; i < eWidth; i++)
                                {
                                        if (currentBit == -1)
                                        {
                                                if (currentDat == dataSize - 1)
                                                        goto planeError;
                                                fullDat = data[currentDat++];
                                                currentBit = 7;
                                        }
                                        aTemp = bitFromChar(fullDat, currentBit);
                                        plane[plan][j * eWidth + i] = aTemp;
                                        currentBit--;
                                }
                        }
                currentDat ++;
                }


                if (drawLocationX + eWidth > (unsigned)image->Width)
                {
                        drawLocationX = eWidth + 2;
                        drawLocationY += maxHeight + 2;
                        maxHeight = 0;
                }
                else
                        drawLocationX += eWidth + 2;

            /*    if (drawLocationX + eWidth > maxBitSizeX)
                        maxBitSizeX = drawLocationX + eWidth;*/
                        
                drawEGAImage(plane, ePlanes, Point(eWidth, eHeight), Point(drawLocationX - eWidth - 2, drawLocationY), false, MBashPalette);

            /*    if (drawLocationY + eHeight > maxBitSizeY)
                        maxBitSizeY = drawLocationY + eHeight;  */

                currentFrame++;

                for (unsigned z = 0; z < ePlanes; z++)
                                delete [] plane[z];

                continue;

                planeError:
                        currentDat += 2; //to force plane error
                        for (unsigned z = 0; z < ePlanes; z++)
                                delete [] plane[z];
                        break;

        }

        delete [] plane;

      //  maxFrames = currentFrame;
    /*    if (currentDat > decomSize)
                Label1->Caption = "Plane error!";
        else
                Label1->Caption = "";*/


}

void CWGame_MonsterBash::drawImage(char *data, CGameObject object, TImage *image)
{
        switch (object.extraData){
                case 64: frmMain->spnPlanes->Visible = true;
                         drawSprite(data, object.objectSize, image); break;//sprite
                case 3: drawEGATiles(data, 0, object.objectSize, false, Point(16, 16), Point(0, 0), 320, false, edpPlane, MBashPalette); break; //tiles-back
                case 4: //tiles-fore
                case 5: drawEGATiles(data, 0, object.objectSize, true, Point(16, 16), Point(0, 0), 320, false, edpPlane, MBashPalette);
                        image->Canvas->Brush->Color = clLime;
                        image->Canvas->FillRect(Rect(0,0,16,16));
                        break; //back-on
        }
        drawPalette(MBashPalette, 16);
}

int CWGame_MonsterBash::unpackFileFromPack(CGameObject object, char* &buffer)
{
        //open the file
        ifstream filein(object.fileName.c_str(), ios::in | ios::binary);
        filein.seekg(object.positionInFile);

        //and read in the data
        MBashHeader header;
        filein.read((char*)&header.nType, sizeof(unsigned short));
        filein.read((char*)&header.nSize, sizeof(unsigned short));
        filein.read((char*)&header.cFilename, 31);
        filein.read((char*)&header.nCompression, sizeof(unsigned short));
        char * bufferRead = new char[header.nSize + 1];
        bufferRead[header.nSize] = '\0';
        filein.read(bufferRead, header.nSize);

        //set up the destination buffer
        if (header.nCompression == 0) //already uncompressed
        {
                buffer = bufferRead;
                return header.nSize;
        };

        //not uncompressed, we're on the road again
        buffer = new char[header.nCompression + 1];
        memset(buffer, header.nCompression + 1, 0);

        /*char * intermediateResult = new char[header.nCompression];
        memset(intermediateResult, header.nCompression, 0);
        int nonRLESize = unLZW(bufferRead, intermediateResult, header.nSize, header.nCompression, 9, 12, false, 256);
        int destCounter = 0;
        int sourceCounter = 0;
        while (sourceCounter < nonRLESize)
        {
                if (intermediateResult[sourceCounter] != (char)144)  //straight copy
                        buffer[destCounter++] = intermediateResult[sourceCounter];

                else
                {
                        sourceCounter++;

                        if ((UCHAR)intermediateResult[sourceCounter] == 0)
                                buffer[destCounter++] = 144;
                        else
                        for (int j = 0; j < ((UCHAR)intermediateResult[sourceCounter])-1; j++)
                                buffer[destCounter++] = intermediateResult[sourceCounter-2];
                }
                sourceCounter++;

        }           
        delete [] intermediateResult;

        buffer[header.nCompression] = 0x0;*/
        deLZWGerald((void*)bufferRead, (void*)buffer, header.nCompression);
        delete [] bufferRead;
        return header.nCompression;

}

void CWGame_MonsterBash::initLevel(CGameObject object)
{
        if (levelBackData)
                delete [] levelBackData;

        if (levelForeData)
                delete [] levelForeData;

        if (levelData)
                delete [] levelData;

        //read level data
        levelData = new char[object.objectSize];
        unpackFileFromPack(object, levelData);

        AnsiString bgName = ((AnsiString)levelData).SubString(1, 31);
        AnsiString fgName = ((AnsiString) ((char*)&levelData[31])).SubString(1, 31);
        AnsiString bonName = ((AnsiString) ((char*)&levelData[62])).SubString(1, 31);

        //request images
        CGameObject bgObject = findObject(bgName.LowerCase(), 3);
        imageToBitmap(bgObject, backgroundTiles);

        CGameObject fgObject = findObject(fgName.LowerCase(), 4);
        imageToBitmap(fgObject, foregroundTiles);

        CGameObject bonObject = findObject(bonName.LowerCase(), 5);
        imageToBitmap(bonObject, bonTiles);

        //make masks

        foregroundMask->Width = foregroundTiles->Width;
        foregroundMask->Height = foregroundTiles->Height;

        for (int x = 0; x < foregroundTiles->Width; x++)
                for (int y = 0; y < foregroundTiles->Height; y++)
                        if (foregroundTiles->Canvas->Pixels[x][y] == clLime)
                        {
                                foregroundMask->Canvas->Pixels[x][y] = clWhite;
                                foregroundTiles->Canvas->Pixels[x][y] = clBlack;
                        }
                        else
                                foregroundMask->Canvas->Pixels[x][y] = clBlack;  

        bonMask->Width = bonTiles->Width;
        bonMask->Height = bonTiles->Height;

        for (int x = 0; x < bonTiles->Width; x++)
                for (int y = 0; y < bonTiles->Height; y++)
                        if (bonTiles->Canvas->Pixels[x][y] == clLime)
                        {
                                bonMask->Canvas->Pixels[x][y] = clWhite;
                                bonTiles->Canvas->Pixels[x][y] = clBlack;
                        }
                        else
                                bonMask->Canvas->Pixels[x][y] = clBlack;

        //request back/fore data
        CGameObject lbdObject = findObject(object.objectName, 1);
        levelBackData = new char[lbdObject.objectSize];
        unpackFileFromPack(lbdObject, levelBackData);

        levelWidth = (unsigned char)levelBackData[0];

     //   file.seekg(file.tellg() + 7);

        levelHeight = ((lbdObject.objectSize - 8) / levelWidth) / 2;

        //file.seekg(file.tellg() + 2);

        CGameObject lfdObject = findObject(object.objectName, 2);
        levelForeData = new char[lfdObject.objectSize];
        unpackFileFromPack(lfdObject, levelForeData);

        drawLevel(Point(0, 0));
}

void CWGame_MonsterBash::drawLevel(TPoint offset)
{
        frmLevelViewer->imgLevel->Canvas->Brush->Style = bsSolid;
        frmLevelViewer->imgLevel->Canvas->Brush->Color = clMoneyGreen;
        frmLevelViewer->imgLevel->Canvas->FillRect(Rect(0,0,frmLevelViewer->imgLevel->Width, frmLevelViewer->imgLevel->Height));
        frmLevelViewer->imgLevel->Canvas->Brush->Style = bsClear;
        drawBack(offset);
        drawForeground(offset);
        drawProperties(offset);

        frmLevelViewer->imgLevel->Repaint();
}

CWGame_MonsterBash::CWGame_MonsterBash()
{
        backgroundTiles = new Graphics::TBitmap;
        foregroundTiles = new Graphics::TBitmap;
        bonTiles = new Graphics::TBitmap;

        foregroundMask = new Graphics::TBitmap;
        bonMask = new Graphics::TBitmap;

        levelBackData = levelForeData = levelData = NULL;
}

CWGame_MonsterBash::~CWGame_MonsterBash()
{
        delete backgroundTiles;
        delete foregroundTiles;
        delete bonTiles;

        delete foregroundMask;
        delete bonMask;

        if (levelBackData)
                delete [] levelBackData;

        if (levelForeData)
                delete [] levelForeData;

        if (levelData)
                delete [] levelData;
}

void CWGame_MonsterBash::drawBack(TPoint offset)
{
        for (int y = 0; y  < frmLevelViewer->imgLevel->Height / 16; y++)
                for (int x = 0; x < frmLevelViewer->imgLevel->Width / 16; x++)
                {
                        if ((y + offset.y < levelHeight) && (x + offset.x < levelWidth))
                        {
                                unsigned tile = ((unsigned short*)levelBackData)[(y + offset.y) * levelWidth + x + offset.x + 4];

                                if (tile > 511)
                                        tile = tile & 0x1FF;
                                BitBlt(frmLevelViewer->imgLevel->Canvas->Handle, x*16, y*16, 16, 16, backgroundTiles->Canvas->Handle, (tile % 20) * 16, (tile / 20) * 16, SRCCOPY);

                        }
                }
}

void CWGame_MonsterBash::drawForeground(TPoint offset)
{
        for (int y = 0; y  < frmLevelViewer->imgLevel->Height / 16; y++)
                for (int x = 0; x < frmLevelViewer->imgLevel->Width / 16; x++)
                {
                        if ((y + offset.y < levelHeight) && (x + offset.x < levelWidth))
                        {
                                unsigned char tile = levelForeData[(y + offset.y) * levelWidth + x + offset.x + 2];
                                if (tile > 128)
                                {
                                        tile -= 128;
                                        BitBlt(frmLevelViewer->imgLevel->Canvas->Handle, x*16, y*16, 16, 16, foregroundMask->Canvas->Handle, (tile % 20) * 16, (tile / 20) * 16, SRCAND);
                                        BitBlt(frmLevelViewer->imgLevel->Canvas->Handle, x*16, y*16, 16, 16, foregroundTiles->Canvas->Handle, (tile % 20) * 16, (tile / 20) * 16, SRCPAINT);
                                }
                                else
                                {
                                        BitBlt(frmLevelViewer->imgLevel->Canvas->Handle, x*16, y*16, 16, 16, bonMask->Canvas->Handle, (tile % 20) * 16, (tile / 20) * 16, SRCAND);
                                        BitBlt(frmLevelViewer->imgLevel->Canvas->Handle, x*16, y*16, 16, 16, bonTiles->Canvas->Handle, (tile % 20) * 16, (tile / 20) * 16, SRCPAINT);
                                }
                        }
                }
}

void CWGame_MonsterBash::drawProperties(TPoint offset)
{
        int special;

        for (int y = 0; y  < frmLevelViewer->imgLevel->Height / 16; y++)
                for (int x = 0; x < frmLevelViewer->imgLevel->Width / 16; x++)
                {
                        if ((y + offset.y < levelHeight) && (x + offset.x < levelWidth))
                        {
                                unsigned tile = ((unsigned short*)levelBackData)[(y + offset.y) * levelWidth + x + offset.x + 4];

                                if (tile > 511)
                                       special = (tile & 0xFE00) >> 9; 
                                else
                                        special = 0;

                                if (special & 32) //if sloping tile
                                {
                                        frmLevelViewer->imgLevel->Canvas->Pen->Color = clLime;
                                        frmLevelViewer->imgLevel->Canvas->Rectangle(x*16, y*16, ((x+1)*16)-1, ((y+1)*16)-1);
                                }
                                else
                                {
                                                if (special & 16) //if 'special property'
                                                {
                                                        frmLevelViewer->imgLevel->Canvas->Pen->Color = clYellow;
                                                        if (special == 16)
                                                                frmLevelViewer->imgLevel->Canvas->Rectangle(x*16, y*16, ((x+1)*16)-1, ((y+1)*16)-1);
                                                }
                                                else
                                                        frmLevelViewer->imgLevel->Canvas->Pen->Color = clWhite;
                                                if (special & 1) //left wall
                                                {
                                                        frmLevelViewer->imgLevel->Canvas->MoveTo(x*16, y*16);
                                                        frmLevelViewer->imgLevel->Canvas->LineTo(x*16, ((y+1)*16)-1);
                                                }
                                                if (special & 2) //right wall
                                                {
                                                        frmLevelViewer->imgLevel->Canvas->MoveTo(((x+1)*16)-2, y*16);
                                                        frmLevelViewer->imgLevel->Canvas->LineTo(((x+1)*16)-2, ((y+1)*16)-1);
                                                }
                                                if (special & 4) //top wall
                                                {
                                                        frmLevelViewer->imgLevel->Canvas->MoveTo(x*16, y*16);
                                                        frmLevelViewer->imgLevel->Canvas->LineTo(((x+1)*16)-1, y*16);
                                                }
                                                if (special & 8) //bottom wall
                                                {
                                                        frmLevelViewer->imgLevel->Canvas->MoveTo(x*16, ((y+1)*16)-2);
                                                        frmLevelViewer->imgLevel->Canvas->LineTo(((x+1)*16)-1, ((y+1)*16)-2);
                                                }
                                        }
                                }

                }
}

//---------------------------------------------------------------------------

#pragma package(smart_init)

