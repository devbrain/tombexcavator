//---------------------------------------------------------------------------


#pragma hdrstop

#include "wackyw.h"
#include <vector>

//std::vector<int > spriteSizeCount;

/*
00      2     Number of files
  02     14     filename1 (the longest name is only 12)
  10      4     length
  14      4     offset-2
*/

TRGB wackyPalette[256];
bool wackyPalLoaded = false;

#include <iostream>

using namespace std;

struct CWackyWheelsHeader{
        char cFilename[15];
        unsigned nLength;
        unsigned nOffset;
};

CGameObject CWGame_WackyWheels::startUnpack(AnsiString fileName)
{
        lastUnpackAttempt.open(fileName.c_str(), std::ios::in | std::ios::binary);
        lastUnpackName = fileName;
        lastUnpackAttempt.read((char*)&fileCount, sizeof(unsigned short));
        currentFile = 0;
        return nextUnpack();
}

CGameObject CWGame_WackyWheels::nextUnpack()
{
        CWackyWheelsHeader header;

        CGameObject result;
        result.inPack = true;

        if (currentFile == fileCount)
        {
                lastUnpackAttempt.close();
                result.objectType = egoNone;
                return result;
        }


        lastUnpackAttempt.read((char*)&header.cFilename, 14);
        header.cFilename[14] = '\0';
        lastUnpackAttempt.read((char*)&header.nLength, sizeof(unsigned));
        lastUnpackAttempt.read((char*)&header.nOffset, sizeof(unsigned));

        result.objectName = ((AnsiString)header.cFilename).LowerCase();
        result.positionInFile = header.nOffset + 2;
        result.objectSize = header.nLength;
        result.fileName = lastUnpackName;

        result.objectType = processFile(result).objectType;

        currentFile++;

        return result;
}

AnsiString CWGame_WackyWheels::getName()
{
        return "Wacky Wheels";
}

AnsiString CWGame_WackyWheels::getFileExtensions()
{
        return "*.dat";
}

CGameObject CWGame_WackyWheels::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (object.objectName == "wacky.dat")
                result.objectType = egoPacked;
        else
        if ((extension == ".mid") || (extension == ".klm"))
                result.objectType = egoMusic;
        else
        if (extension == ".voc")
                result.objectType = egoSound;
        else
        if (extension == ".pcx")
                result.objectType = egoImage;
        else
        if (object.objectName.SubString(object.objectName.Length()-2, 3) == ".sp")
                result.objectType = egoSprite;
        else
        if (object.objectSize == 4000)
                result.objectType = egoDOSScreen;
        return result;
}

void CWGame_WackyWheels::drawImage(char *data, CGameObject object, TImage *image)
{
        if (!wackyPalLoaded)
        {
                CGameObject palInfo = findObject("a_f1.pcx", 0);
                char *palData;

                unpackFileFromPack(palInfo,palData);

                int offset = palInfo.objectSize - 769;

                for (int i = 0; i < 256; i++)
                        wackyPalette[i] = TRGB(palData[offset + (i * 3 + 1)], palData[offset + (i * 3 + 2)], palData[offset + (i * 3)]);

                delete [] palData;

                wackyPalLoaded = true;
        }

        if (object.objectType == egoSprite)
        {
                AnsiString strippedName = object.objectName.SubString(1, object.objectName.Length() - 3);
                if ((strippedName == "panda") || (strippedName == "pelican") || (strippedName == "ringo") || (strippedName == "shark") ||(strippedName == "tiger") ||
                    (strippedName == "camel") || (strippedName == "ele") ||(strippedName == "moose") || (strippedName == "digger") || (strippedName == "aj") ||
                    (strippedName == "puf") || (strippedName == "cars"))
                        drawVGATiles(data, 0, object.objectSize, TPoint(38, 28), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width);
                else
                if (strippedName == "hogmis")
                        drawVGATiles(data, 0, object.objectSize, TPoint(18, 13), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width);
                else
                if (strippedName == "giggles")
                        drawVGATiles(data, 0, object.objectSize, TPoint(38, 44), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width);
                else
                if ((strippedName == "bronzem") || (strippedName == "silverm") || (strippedName == "goldm") || (strippedName == "bonusb") || (strippedName == "bonuss") || (strippedName == "bonusg"))
                        drawVGATiles(data, 0, object.objectSize, TPoint(78, 50), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width);
                else
                if (strippedName == "handle")
                        drawVGATiles(data, 0, object.objectSize, TPoint(20, 23), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width);
                else
                if (strippedName[1] == 'h')
                        drawVGATiles(data, 0, object.objectSize, TPoint(32, 24), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width);
                else
                if (strippedName == "crack")
                        drawVGAImageColumn(data, 0, TPoint(84, 62), TPoint(0, 0), wackyPalette);
                else
                if ((strippedName == "ob1") || (strippedName == "ob5") || (strippedName == "ob6") || (strippedName == "ob7") || (strippedName == "ob8") || (strippedName == "ob9"))
                        drawVGAImageColumn(data, 0, TPoint(28, 28), TPoint(0, 0), wackyPalette);
                else
                if ((strippedName == "ob2") || (strippedName == "ob3") || (strippedName == "ob4") || (strippedName == "ob10") || (strippedName == "ob11") || (strippedName == "ob13"))
                        drawVGAImageColumn(data, 0, TPoint(14, 28), TPoint(0, 0), wackyPalette);
                else
                if (strippedName == "ob12")
                        drawVGAImageColumn(data, 0, TPoint(32, 24), TPoint(0, 0), wackyPalette);
                else
                if (strippedName == "wfont1")
                        drawVGATiles(data, 0, object.objectSize, TPoint(15, 13), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width);
                if (strippedName == "action")
                        drawVGAImageColumn(data, 0, TPoint(251, 6), TPoint(0, 0), wackyPalette);
                else
                if (strippedName == "spark")
                        drawVGATiles(data, 0, object.objectSize, TPoint(10, 9), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width);
                else
                if (strippedName == "icons")
                {                            /* 26 * 21 * 6 */
                        drawVGATiles(data, 0, 3276, TPoint(26, 21), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width);
                        drawVGAImageColumn(data, 3276, TPoint(42, 19), TPoint(0, 23), wackyPalette);
                        drawVGATiles(data, 3276 + (42*19), object.objectSize, TPoint(10, 15), TPoint(0, 67), wackyPalette, true, image->Picture->Bitmap->Width); //10x15 x10 (7-segment digits 0-9)
                }
                else
                if (strippedName == "dope") //80x72 x2  (Dopefish) AND 25x15 x1  (bubbles)
                {
                        drawVGATiles(data, 0, 80*72*2, TPoint(80, 72), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width);
                        drawVGAImageColumn(data, 80*72*2, TPoint(25, 15), TPoint(0, 74), wackyPalette);
                }
                else
                if (strippedName == "lap") // 22x29 x18 (digits), 80x17 x2  (wrong way), 38x41 x1  (empty frame), 126x19 x1  (retrys&hog frames), 154x9  x1  (0-9Order Me)
                {
                        drawVGATiles(data, 0, 11484, TPoint(22, 29), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width);
                        drawVGATiles(data, 11484, 14204, TPoint(80, 17), TPoint(0, 31), wackyPalette, true, image->Picture->Bitmap->Width);
                        drawVGAImageColumn(data, 14204, TPoint(38, 41), TPoint(0, 50), wackyPalette);
                        drawVGAImageColumn(data, 15762, TPoint(126, 19), TPoint(0, 93), wackyPalette);
                        drawVGAImageColumn(data, 17148, TPoint(154, 9), TPoint(0, 114), wackyPalette);
                }
                else
                if (strippedName == "ofont")
                {

                        drawVGATiles(data, 0, 3904, TPoint(8, 8), TPoint(0, 0), wackyPalette, true, image->Picture->Bitmap->Width); //8x8  x61 (ascii)  AND
                        drawVGAImageColumn(data, 3904, TPoint(92, 41), TPoint(0, 16), wackyPalette); //92x41 x1  (Apogee) AND
                        drawVGATiles(data, 7676, object.objectSize, TPoint(8, 8), TPoint(0, 59), wackyPalette, true, image->Picture->Bitmap->Width); //8x8 x137 (ascii)

                }
                else
                if (strippedName == "effects")
                {
                   drawVGAImageColumn(data, 0, Point(60, 12), Point(0, 25), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x2D0, Point(30, 9), Point(0, 14), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x3DE, Point(60, 12), Point(62, 25), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x6AE, Point(30, 9), Point(32, 14), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x7BC, Point(60, 12), Point(124, 25), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0xA8C, Point(30, 9), Point(64, 14), wackyPalette);//165x18 AND
                   drawVGATiles(data, 2970, 3546, TPoint(12, 24), TPoint(0, 39), wackyPalette, true, image->Picture->Bitmap->Width);//12x24 x2 (watereffect) AND
                   drawVGATiles(data, 3546, 7802, TPoint(38, 28), TPoint(0, 65), wackyPalette, true, image->Picture->Bitmap->Width); //38x28 x4 (waterflosch) AND
                   drawVGATiles(data, 7802, 13946, TPoint(32, 24), TPoint(0, 95), wackyPalette, true, image->Picture->Bitmap->Width); // (periscope)   AND

                   drawVGAImageColumn(data, 0x367A, Point(60, 12), Point(0, 121), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x394A, Point(30, 9), Point(0, 135), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x3A58, Point(60, 12), Point(62, 121), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x3D28, Point(30, 9), Point(32, 135), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x3E36, Point(30, 9), Point(64, 135), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x3F44, Point(30, 9), Point(96, 135), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x4052, Point(60, 12), Point(124, 121), wackyPalette);//165x18 AND

                   drawVGATiles(data, 0x4322, 0x53C2, TPoint(38, 28), TPoint(0, 146), wackyPalette, true, image->Picture->Bitmap->Width); //38x28 x4 (waterflosch) AND
                   drawVGATiles(data, 0x53C2, 0x6BC2, TPoint(32, 24), TPoint(0, 176), wackyPalette, true, image->Picture->Bitmap->Width); // (periscope)   AND

                   drawVGAImageColumn(data, 0x6BC2, Point(60, 12), Point(186, 121), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x6E92, Point(30, 9), Point(128, 135), wackyPalette);//165x18 AND

                   drawVGAImageColumn(data, 0x6FA0, Point(60, 12), Point(248, 121), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x7270, Point(30, 9), Point(128, 135), wackyPalette);//165x18 AND
                   drawVGAImageColumn(data, 0x737E, Point(30, 9), Point(160, 135), wackyPalette);//165x18 AND
                }
                else
                if (strippedName == "genef")
                {
                        drawVGATiles(data, 0, 3864, Point(28, 23), Point(0, 0), wackyPalette, true, image->Picture->Bitmap->Width); //28x24 x6 (medals) AND
                        drawVGAImageColumn(data, 3864, Point(45, 13), Point(0, 25), wackyPalette); //AND cups
                        drawVGATiles(data, 4449, 12961, Point(38, 28), Point(0, 40), wackyPalette, true, image->Picture->Bitmap->Width); //38x28 x8 (startlion etc)
                        drawVGAImageColumn(data, 12961, Point(28, 22), Point(0, 70), wackyPalette);
                        drawVGAImageColumn(data, 13577, Point(12, 13), Point(0, 94), wackyPalette);
                        drawVGAImageColumn(data, 13733, Point(77, 9), Point(0, 109), wackyPalette);
                        drawVGAImageColumn(data, 14426, Point(19, 14), Point(0, 120), wackyPalette);
                }
                else
                        drawVGAImageColumn(data, 0, TPoint(1, 1), TPoint(0, 0), wackyPalette);
        drawPalette(wackyPalette, 256);
        }
        else //PCX
                drawPCX(data, object.objectSize);

}

EMusicType CWGame_WackyWheels::musicType(CGameObject object)
{
        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (extension == ".mid")
                return wmusMID;
        else
                return wmusOther;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
