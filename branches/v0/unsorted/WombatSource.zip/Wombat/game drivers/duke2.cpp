//---------------------------------------------------------------------------


#pragma hdrstop

#include "duke2.h"
#include <sysutils.hpp>

struct CDuke2Sprite {
        unsigned short usuallyZero, whoKnows;
        unsigned short height, width;
        unsigned int offset;
        unsigned int hey;
};

TRGB dukePalette[16];
bool paletteLoaded = false;

AnsiString CWGame_Duke2::getName()
{
        return "Duke Nukem 2";
}

AnsiString CWGame_Duke2::getFileExtensions()
{
        return "*.cmp";
}

CGameObject CWGame_Duke2::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName.LowerCase();
        result.objectName = object.objectName;

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (extension == ".cmp")
                result.objectType = egoPacked;
        else
        if (extension == ".imf")
                result.objectType = egoMusic;
        else
        if (object.objectName.SubString(1, 5) == "czone")
                result.objectType = egoForeTile;
        else
        if (object.objectSize == 32000)
                result.objectType = egoBackTile;
        else
        if (object.objectSize == 32048)
                result.objectType = egoFullscreen;
        else
        if ((object.objectSize > 64999) && (object.objectSize < 70000) && ((char)object.objectName[1] >= 'l') && ((char)object.objectName[1] <= 'o'))
                result.objectType = egoLevel;
        else
        if ((object.objectName == "ordertxt.mni") || (object.objectName == "text.mni") ||
            (object.objectName == "options.mni") || (object.objectName == "help.mni"))
                result.objectType = egoText;
        else
        if (object.objectName == "actors.mni")
                result.objectType = egoSprite;
        else
        if ((object.objectName.SubString(1, 3) == "sb_") || (object.objectName.SubString(1, 5) == "intro"))
                result.objectType = egoSound;
        else
        if (object.objectSize == 4000)
                result.objectType = egoDOSScreen;
        return result;
}

#pragma warn -aus
void CWGame_Duke2::drawImage(char *data, CGameObject object, TImage *image)
{
        TPoint drawOffset = Point(0, 0);
        char * spriteData;
        int maxHeight = 0;

        if (!paletteLoaded)
        {
                CGameObject palInfo = findObject("gamepal.pal", 0);
                char *palData;

                unpackFileFromPack(palInfo,palData);

                for (int i = 0; i < 16; i++)
                        dukePalette[i] = TRGB(FbitColorTo8bit(palData[i * 3]), FbitColorTo8bit(palData[i * 3 + 1]), FbitColorTo8bit(palData[i * 3 + 2]));

                paletteLoaded = true;
                delete [] palData;
        }
        TRGB thisPal[16];
        switch (object.objectType){
                case egoFullscreen: for (int i = 0; i < 16; i++)
                                        thisPal[i] = TRGB(FbitColorTo8bit(data[32000 + (i * 3)]), FbitColorTo8bit(data[32000 + (i * 3 + 1)]), FbitColorTo8bit(data[32000 + (i * 3 + 2)]));
                                    drawPalette(thisPal, 16);
                                    drawEGANoProcess(data, 0, 4, Point(320, 200), Point(0, 0), false, edpPlane, thisPal); break;
                case egoBackTile: drawEGATiles(data, 0, object.objectSize, false, Point(8, 8), Point(0, 0), 320, false, edpHeight, dukePalette); break;
                case egoForeTile: drawEGATiles(data, 3600, 35600, false, Point(8, 8), Point(0, 0), 320, false, edpHeight, dukePalette);
                                  drawEGATiles(data, 35600, 42000, true, Point(8, 8), Point(0, 220), 320, false, edpHeight, dukePalette); break;
                case egoSprite:   CGameObject spriteInfo = findObject("actrinfo.mni", 0);

                                  unpackFileFromPack(spriteInfo, spriteData);

                                  unsigned short firstOffset = (((unsigned short *)(spriteData))[0]) * 2;
                                  unsigned short headerOffset = 0;
                                  unsigned short frameCount;
                                  unsigned short notSure;

                                  CDuke2Sprite * sprite = (CDuke2Sprite*)(&spriteData[firstOffset + 4]);

                                  unsigned i = 0;

                                  while ((unsigned)(i * 2) < (unsigned)firstOffset)
                                  {
                                        headerOffset = (((unsigned short *)(spriteData))[i]) * 2;
                                        frameCount = *((unsigned short*)(&spriteData[headerOffset]));

                                        notSure = *((unsigned short*)(&spriteData[headerOffset + 2]));

                                        for (unsigned frame = 0; frame < (unsigned)frameCount; frame++)
                                        {
                                                sprite = (CDuke2Sprite*)(&spriteData[headerOffset + 4 + (frame * 16)]);

                                                if (drawOffset.x + sprite->width * 8 >= image->Picture->Bitmap->Width)
                                                {
                                                        drawOffset.x = 0;
                                                        drawOffset.y += maxHeight + 2;
                                                        maxHeight = 0;
                                                }

                                                drawEGATiles(data, sprite->offset, sprite->offset + (40 * sprite->width * sprite->height), true, Point(8, 8), drawOffset, sprite->width * 8, false, edpHeight, dukePalette);

                                                drawOffset.x += (sprite->width * 8) + 2;
                                                if (sprite->height * 8 > maxHeight)
                                                        maxHeight = sprite->height * 8;
                                        }

                                        i++;
                                }

                                delete [] spriteData;
                                break;
        }
        drawPalette(dukePalette, 16);
}
#pragma warn +aus

//---------------------------------------------------------------------------

#pragma package(smart_init)
