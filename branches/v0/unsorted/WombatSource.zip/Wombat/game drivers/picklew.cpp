//---------------------------------------------------------------------------


#pragma hdrstop

#include "picklew.h"

struct CPickleHeader { //before every file
char filename[12];
unsigned offset, length; 
};

using namespace std;

AnsiString CWGame_PickleWars::getName()
{ return "Pickle Wars"; }

AnsiString CWGame_PickleWars::getFileExtensions()
{
        return "*.arc;*.gf;*.mis";
}

CGameObject CWGame_PickleWars::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-2, 3);

        if ((extension == "arc") || (extension == ".gf") || (extension == "mis"))
                result.objectType = egoPacked;

        return result;
}

void CWGame_PickleWars::drawImage(char *data, CGameObject object, TImage *image)
{
}

CGameObject CWGame_PickleWars::startUnpack(AnsiString fileName)
{
        lastUnpackAttempt.open(fileName.c_str(), ios::in | ios::binary);
        lastUnpackName = fileName;
        return nextUnpack();
}

CGameObject CWGame_PickleWars::nextUnpack()
{
        CGameObject result;
        result.inPack = true;
        result.objectType = egoNone;

        if (lastUnpackAttempt.eof())
                return result;  

        CPickleHeader pickleHeader;

        lastUnpackAttempt.read((char*)&pickleHeader, sizeof(pickleHeader));
        result.objectName = (AnsiString)pickleHeader.filename;
        result.positionInFile = lastUnpackAttempt.tellg() + 20;
        result.objectSize = pickleHeader.length;
        result.fileName = lastUnpackName;

        result.objectType = processFile(result).objectType;

        lastUnpackAttempt.seekg(pickleHeader.length + 128);

        return result;

}

//---------------------------------------------------------------------------

#pragma package(smart_init)
