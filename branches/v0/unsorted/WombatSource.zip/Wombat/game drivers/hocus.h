//---------------------------------------------------------------------------

#ifndef hocusH
#define hocusH

#include "wombatCommon.h"

struct CWGame_Hocus: public CSimpleExtractor {

        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "";};
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);

        virtual CGameObject nextUnpack();
        virtual CGameObject startUnpack(AnsiString fileName);

        virtual EMusicType musicType(CGameObject object){return wmusMID;};

        private:
        int currentFile;
        unsigned oldValue;
        std::ifstream exeFile;

};
//---------------------------------------------------------------------------
#endif
