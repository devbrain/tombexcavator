//---------------------------------------------------------------------------

#ifndef keen13H
#define keen13H

#include "wombatCommon.h"

struct CWGame_Keen13: public IWombatGame {
        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "";};
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);

        virtual CGameObject startUnpack(AnsiString fileName){CGameObject o; return o;};
        virtual CGameObject nextUnpack(){CGameObject o; return o;};
        virtual int unpackFileFromPack(CGameObject object, char* &buffer){return 0;};
};
//---------------------------------------------------------------------------
#endif
