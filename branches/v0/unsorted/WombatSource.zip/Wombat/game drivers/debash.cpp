#include <iostream>
#include <stdlib.h>
#include <assert.h>

using namespace std;

typedef          int       BOOL;
typedef unsigned char      BYTE;
typedef unsigned short int WORD;
typedef unsigned int       DWORD;

static DWORD buf;   // input bit buffer
static int   size;  // current number of bits per input code
static DWORD mask;  // current mask to AND input bits with (== size**2 - 1)
static int   bufSize;  // number of good bits still in buf

static WORD* table;
static WORD* lastTableEntry;
static WORD* newCode;  // points into table where the next bump
                       //   in code size will occur.
static bool rep90;
static BYTE* odst; // original dst
static BYTE* edst; // end of dst (odst + dstSize)


BOOL
initLZW()
{
  table = new WORD[0x3D02/2];
  return (int)table;
}


void
exitLZW()
{
  delete table; table = 0;
}

static void
put(BYTE*& dst, int code)  // #683D
{
  // I improved the logic slightly here:
  //    using the rep90 flag to indicate the special
  //    handling of the first byte (can't check
  //    the prev byte ouput -- ain't one! might
  //    cause an access violation otherwise)
  if (rep90) {
    rep90 = false;             // #6849
    *dst++ = (BYTE)code;       // #684E
  } else if (dst[-1] != 0x90)  // #6842
    *dst++ = (BYTE)code;       // #684E
  else if (code == 0)          // #6858
    rep90 = true;              // #6867
  else {
    BYTE* d = dst-2;           // #685E
    BYTE rep = *d;             // #6861
    while (code--)             // #6863
      *d++ = rep;
    dst = d;
  }  
}


static void
putTail(BYTE*& dst, int code)  // #6837
{
  do
    code = *(WORD*)((BYTE*)table+code); // #6837
  while (code > 0x100);        // #6838
  put(dst, code);              // #683D
}

  
static void
putHead(BYTE*& dst, int code)  // #6825
{
  if (code <= 0x100)           // #6825
    put(dst, code);            // #683D
  else {
    code = *(WORD*)((BYTE*)table+code);
    putHead(dst, code);        // #682D
    putTail(dst, code);        // #6830
  }  
}  

static int reset(DWORD*& src, BYTE*& dst);

static int
get(DWORD*& src, BYTE*& dst) // #67A2
{
  int code;
  
  if (bufSize < size) {            // #67A2
    DWORD d = *src++;              // #67AB
    code = d << bufSize | buf;     // #67AC
    buf = d >> size - bufSize;     // #67C0
    bufSize += 32 - size;          // #67B2 
  } else {
    code = buf;                    // #67D4
    buf >>= size;                  // #67D8
    bufSize -= size;               // #67DA
  }
  if ((code &= mask) > 0x100)      // #67DC
    code = code * 4 - 0x300;       // #67ED
  else if (code == 0x100) {        // #67E1
    if (lastTableEntry != table + (0x3D00/2)) {  // #67F5
      putHead(dst, *lastTableEntry); // #67FB
      if (dst == edst)               // #6801
        assert(!"hope this don't happen");
      // need to end check?
    }  
    code = reset(src, dst);          // #6807
  }
  return code;
}
  
static int
reset(DWORD*& src, BYTE*& dst)  // #6807
{
  mask = 0x1FF;                 // #6807
  newCode = table + 0x500 / 2;  // #680E
  buf = 0;                      // #6815
  size = 9; bufSize = 0;        // #6819
  int code = get(src, dst);     // #681F
  *(lastTableEntry = table + 0x82) = (WORD)code;  // #6822
  return code;
}

void
deLZWGerald(void* _src, void *_dst, int dstSize)
{
  bool preallocated = table != 0;      // #670B
  if (!preallocated && !initLZW()) return;  // #6712
    
  BYTE* dst = (BYTE*)_dst;             // #66F9
  edst = (odst = (BYTE*)_dst) + dstSize;  // #66FC...
  DWORD* src = (DWORD*)_src;           // #6702
  rep90 = true;
  reset(src, dst);                     // #6724
  do {
    int code = get(src, dst);          // #6727
    if (lastTableEntry == table + (0x3D00/2)) { // #672A
      *lastTableEntry = (WORD)code;    // #6794
      putHead(dst, code);              // #6796
    } else {
      int lastCode = *lastTableEntry;
      *++lastTableEntry = (WORD)code;  // #6730...
      *++lastTableEntry = (WORD)code;  // #6734...
      putHead(dst, lastCode);          // #673B
      if (lastTableEntry == newCode)   // #673F
        if (size == 12)                // #6771
          putHead(dst, *lastTableEntry);  // #6794
        else {
          size++;                      // #6776
          mask = (mask << 1) + 1;      // #6778...
          newCode = (WORD*)((BYTE*)table + (1 << size + 2) - 0x300);  // #6782...
        }  
    }  
  } while (dst != edst);               // #6745
  
  if (!preallocated) exitLZW();        // #674D
}


int main(int argc, char *argv[])
{
  return 0;
}   
