//---------------------------------------------------------------------------


#pragma hdrstop

#include "duke1.h"

#include <iostream>

using namespace std;

AnsiString CWGame_Duke1::getName()
{
        return "Duke Nukum";
}

AnsiString CWGame_Duke1::getFileExtensions()
{
        return "*.dn1;*.dn2;*.dn3";
}

CGameObject CWGame_Duke1::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        ifstream file(object.fileName.c_str(), ios::in | ios::binary);
        file.seekg(0, ios::end);
        result.objectSize = file.tellg();
        file.close();

        if (result.objectSize == 32000)
                result.objectType = egoFullscreen;
        else
        if (result.objectSize == 8064)
                result.objectType = egoSprite;
        else
        if (result.objectSize == 20803)
                result.objectType = egoBackTile;
        else
        if (object.objectName.SubString(1, 5) == "world")
                result.objectType = egoLevel;
        else
        if ( (object.objectName.SubString(1, 10) == "duke1-b.dn") || (object.objectName.SubString(1, 8) == "duke1.dn"))
                result.objectType = egoSound;
        else
        if ( (object.objectName.SubString(1, 4) == "font") || (object.objectName.SubString(1, 6) == "border"))
                result.objectType = egoImage;
        return result;
}

void CWGame_Duke1::drawImage(char *data, CGameObject object, TImage *image)
{
        int currentFrame = 0;
        int bob;

        switch (object.objectType){
        case egoFullscreen: drawEGANoProcess(data, 0, 4, Point(320, 200), Point(0, 0), false, edpPlane, defaultPalette); break;
        case egoSprite:
                         while ((unsigned)(3 + (currentFrame * 160)) < object.objectSize)
                         {
                                bob = currentFrame;
                                drawEGANoProcess(data, 3 + (currentFrame * 160), 5, TPoint(16, 16), Point(((currentFrame / 4) +  (bob / 4) + (currentFrame % 2)) * 16, ((currentFrame / 2) % 2) * 16), true, edpWidth, defaultPalette);
                                currentFrame++;
                         }
                         break;
        case egoBackTile: drawEGATiles(data, 3, object.objectSize, true, Point(16, 16), Point(0, 0), 208, true, edpWidth, defaultPalette); break;
        case egoImage: if (object.objectName.SubString(1, 6) == "border")
                                drawEGATiles(data, 3, object.objectSize, true, Point(16, 16), Point(0, 0), 320, true, edpWidth, defaultPalette);
                       else
                                drawEGATiles(data, 3, object.objectSize, true, Point(8, 8), Point(0, 0), 320, true, edpWidth, defaultPalette); break;
        }

}

int CWGame_Duke1::unpackFileFromPack(CGameObject object, char* &buffer)
{
        return 0;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
