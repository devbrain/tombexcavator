//---------------------------------------------------------------------------

#ifndef replogleH
#define replogleH

#include "wombatCommon.h"

struct CWExtractor_Replogle: public CSimpleExtractor {
        virtual CGameObject nextUnpack();
        virtual CGameObject startUnpack(AnsiString fileName);
};
//---------------------------------------------------------------------------
#endif
