//---------------------------------------------------------------------------


#pragma hdrstop

#include "dune2.h"

#include <iostream>

using namespace std;

CGameObject CWGame_Dune2::startUnpack(AnsiString fileName)
{
        lastUnpackAttempt.open(fileName.c_str(), ios::in | ios::binary);
        lastUnpackName = fileName;
        return nextUnpack();
}

CGameObject CWGame_Dune2::nextUnpack()
{   
        CGameObject result;
        result.inPack = true;

        char fileName[13];
        memset(fileName, 0, 13);

        unsigned long dataStart;
        lastUnpackAttempt.read((char*)&dataStart, sizeof(unsigned long));

        result.positionInFile = dataStart;

        if (dataStart == 0)
        {
                lastUnpackAttempt.close();
                result.objectType = egoNone;
                return result;
        }

        char c;
        int currentPos = 0;
        do
        {
                lastUnpackAttempt.read(&c, sizeof(char));
                fileName[currentPos++] = c;
        }
        while (c != 0);

        lastUnpackAttempt.read((char*)&dataStart, sizeof(unsigned long));

        result.objectSize = dataStart - result.positionInFile;

        lastUnpackAttempt.seekg(lastUnpackAttempt.tellg() - sizeof(unsigned long));

        if (dataStart == 0)
        {
                unsigned z;
                z = lastUnpackAttempt.tellg();
                lastUnpackAttempt.seekg(0, ios::end);
                result.objectSize = lastUnpackAttempt.tellg() - result.positionInFile;
                lastUnpackAttempt.seekg(z);
        }

        result.objectName = ((AnsiString)fileName).LowerCase();
        result.fileName = lastUnpackName;

        result.objectType = processFile(result).objectType;

        result.objectName = result.objectName + " " + IntToStr(result.objectSize);

        return result;
}

AnsiString CWGame_Dune2::getName()
{
        return "Dune 2";
}

AnsiString CWGame_Dune2::getFileExtensions()
{
        return "*.pak";
}

CGameObject CWGame_Dune2::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (extension == ".pak")
                result.objectType = egoPacked;
        else
        if (extension == ".voc")
                result.objectType = egoSound;
        else
        if (extension == ".wsa")
                result.objectType = egoImage;
        else
        if (extension == ".shp")
                result.objectType = egoSprite;
        else
        if (extension == ".cps")
                result.objectType = egoFullscreen;
        /*else
        if (object.objectName.SubString(object.objectName.Length()-2, 3) == ".sp")
                result.objectType = egoSprite;   */
        return result;
}

void CWGame_Dune2::drawImage(char *data, CGameObject object, TImage *image)
{     
}



//---------------------------------------------------------------------------

#pragma package(smart_init)
