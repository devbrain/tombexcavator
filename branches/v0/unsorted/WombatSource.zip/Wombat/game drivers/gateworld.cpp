//---------------------------------------------------------------------------


#pragma hdrstop

#include "gateworld.h"
#include <dialogs.hpp>

struct CGateWorldHeader {
        char name[12];
        int unknown;
        unsigned int offset;
        unsigned int size;
        int unknown1;
        int unknown2;
};

AnsiString CWGame_GateWorld::getName()
{ return "GateWorld"; }

AnsiString CWGame_GateWorld::getFileExtensions()
{
        return "*data.gw*";
}

/*

DIM homebrewfilefolder AS STRING * 20
GET #1, , homebrewfilefolder
IF homebrewfilefolder <> "HomeBrew File Folder" THEN
  PRINT COMMAND$ + " is not a HomeBrew File Folder file"
  CLOSE #1
  END
END IF

DIM filename AS STRING * 12
DIM contents AS STRING * 1

GET #1, 35, filenumber%
FOR file% = 1 TO filenumber%
  GET #1, file% * 32 + 33, filename
  y% = 1
withoutzeros:
  IF ASC(MID$(filename, y%, 1)) = 0 THEN
    filename2$ = LEFT$(filename, y% - 1)
  ELSE
    IF y% < 12 THEN
      y% = y% + 1
      GOTO withoutzeros
    ELSE
      filename2$ = filename
    END IF
  END IF

  GET #1, file% * 32 + 49, offset&
  GET #1, , length&

  OPEN filename2$ FOR BINARY AS #2
  FOR y& = 1 TO length&
    GET #1, offset& + y&, contents
    PUT #2, , contents
  NEXT y&
  CLOSE #2
  PRINT filename2$ + " written"
NEXT file%

*/

CGameObject CWGame_GateWorld::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        AnsiString extensionLong = object.objectName.SubString(object.objectName.Length()-7, 7);

        if (extensionLong == "data.gw")
        {
                result.objectType = egoPacked;
                return result;
        }

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (extension == ".hpi")
                result.objectType = egoImage;
        else
        if (extension == ".hle")
                result.objectType = egoLevel;
        else
        if (extension == ".hsk")
                result.objectType = egoSprite;

        return result;
}

void CWGame_GateWorld::drawImage(char *data, CGameObject object, TImage *image)
{
        if (object.objectType == egoImage)
        {
                TRGB thisPalette [256];
                for (int i = 0; i < 256; i++)
                        thisPalette[i] = TRGB(data[64 + (i * 3)] << 2, data[64 + (i * 3 + 1)] << 2, data[64 + (i * 3 + 2)] << 2);
                unsigned short width = ((unsigned short*)data)[16];
                unsigned short height = ((unsigned short*)data)[19];
                char * image = new char[width *  height];
                unsigned positionInImage = 0;
                unsigned positionInData = 0;
                unsigned char instruction;
                unsigned char dataToDraw;
                while (positionInImage < (unsigned)(width * height))
                {
                        instruction = data[832 + positionInData];
                        if (instruction > 127) //RLE length
                        {
                                unsigned char amount = instruction & ((unsigned char) 0x7F);
                                for (unsigned char i = 0; i < amount; i++)
                                        image[positionInImage++] = data[832 + positionInData + 1];
                                positionInData += 2;
                        }
                        else
                        {
                                positionInData++;
                                for (int i = 0; i < instruction; i++)
                                        image[positionInImage++] = data[832 + positionInData++];
                        }
                }

                drawVGAImage(image, 0, Point(width, height), Point(0, 0), thisPalette);
                delete [] image;
        }
        else //hullo, sprite!
        {
                unsigned short width = ((unsigned short*)data)[38];
                unsigned short height = ((unsigned short*)data)[39];
                unsigned short frames = ((unsigned short*)data)[35];
                int currentLocation = 64;
                int tilesToWidth = 320 / width;
                for (unsigned short frame = 0; frame < frames; frame++){
                        unsigned char * extraDat = &((unsigned char*)data)[currentLocation];
                        drawVGAImage(data, currentLocation + 16, Point(width, height - extraDat[2]), Point((frame % tilesToWidth) * width, (frame / tilesToWidth) * height), crashPalette);
                        currentLocation += 16 + (width * (height - extraDat[2]));
                }
        }
}

CGameObject CWGame_GateWorld::startUnpack(AnsiString fileName)
{
        lastUnpackAttempt.open(fileName.c_str(), std::ios::in | std::ios::binary);
        lastUnpackName = fileName;
        char ID[21];
        ID[20] = '\0';
        lastUnpackAttempt.read((char*)&ID, 20);
        if ((AnsiString)ID != "HomeBrew File Folder")
                fileCount = 0;
        else
        {
                lastUnpackAttempt.seekg(34);
                lastUnpackAttempt.read((char*)&fileCount, sizeof(fileCount));
        }
        currentFile = 0;
        lastUnpackAttempt.seekg(64);
        return nextUnpack();
}

CGameObject CWGame_GateWorld::nextUnpack()
{
        CGateWorldHeader header;

        CGameObject result;
        result.inPack = true;

        if (currentFile == fileCount)
        {
                lastUnpackAttempt.close();
                result.objectType = egoNone;
                return result;
        }


        lastUnpackAttempt.read((char*)&header.name, 12);
        lastUnpackAttempt.read((char*)&header.unknown, sizeof(int));
        lastUnpackAttempt.read((char*)&header.offset, sizeof(unsigned));
        lastUnpackAttempt.read((char*)&header.size, sizeof(unsigned));
        lastUnpackAttempt.read((char*)&header.unknown1, sizeof(int));
        lastUnpackAttempt.read((char*)&header.unknown2, sizeof(int));

        result.objectName = ((AnsiString)header.name).LowerCase();
        result.positionInFile = header.offset;
        result.objectSize = header.size;
        result.fileName = lastUnpackName;

        result.objectType = processFile(result).objectType;

        currentFile++;

        return result;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
