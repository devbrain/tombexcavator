//----/-----------------------------------------------------------------------


#pragma hdrstop

#include "mstryker.h"

#include <sysutils.hpp>

AnsiString CWGame_MStryker::getName()
{
        return "Major Stryker";
}

AnsiString CWGame_MStryker::getFileExtensions()
{
        return "volume*.ms*";
}

CGameObject CWGame_MStryker::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName.LowerCase();
        result.objectName = object.objectName;

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if ((object.objectName.SubString(1, 6) == "volume") && ((extension == ".ms1") || (extension == ".ms2") || (extension == ".ms3")))
                result.objectType = egoPacked;
        else
        if (extension == ".imf")
                result.objectType = egoMusic;
        else
        if ((extension == ".voc") || (extension == ".snd"))
                result.objectType = egoSound;
        else
        if (object.objectSize == 30720)
                result.objectType = egoBackTile;
        else
        if (object.objectName.SubString(object.objectName.Length()-3, 3) == ".ms")
                result.objectType = egoText;
        else
        if (object.objectSize == 32000)
                result.objectType = egoFullscreen;
        else
        if (object.objectSize == 38400)
                result.objectType = egoForeTile;
        else
        if (object.objectSize == 4000)
                result.objectType = egoDOSScreen;
        else
        if (object.objectSize == 20480)
                result.objectType = egoImage;
        return result;
}

void CWGame_MStryker::drawImage(char *data, CGameObject object, TImage *image)
{
        switch (object.objectType){
                case egoFullscreen: drawEGANoProcess(data, 0, 4, Point(320, 200), Point(0, 0), false, edpPlane, defaultPalette); break;
                case egoBackTile: drawEGATiles(data, 0, object.objectSize, false, Point(16, 16), Point(0, 0), 320, false, edpWidth, defaultPalette); break;
                case egoForeTile: drawEGATiles(data, 0, object.objectSize, true, Point(16, 16), Point(0, 0), 320, true, edpWidth, defaultPalette); break;
                case egoImage: drawEGATiles(data, 0, object.objectSize, false, Point(16, 16), Point(0, 0), 256, false, edpWidth, defaultPalette); break;
        }
}

ESoundType CWGame_MStryker::soundType(CGameObject object)
{
        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);
        if (extension == ".snd")
                return wsndSnd;
        else
                return wsndVoc;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
