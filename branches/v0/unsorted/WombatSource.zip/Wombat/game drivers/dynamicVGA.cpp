//---------------------------------------------------------------------------


#pragma hdrstop

#include "dynamicVGA.h"

#include "dynamic.h"

#include <iostream>

#include "dynamicCplVGA.h"

using namespace std;

AnsiString CWGame_DynamicVGA::getFileExtensions()
{
        return "*.*";
}

CGameObject CWGame_DynamicVGA::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoImage;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        ifstream file(object.fileName.c_str(), ios::in | ios::binary);
        file.seekg(0, ios::end);
        result.objectSize = file.tellg();
        file.close();

        return result;
}

void CWGame_DynamicVGA::drawImage(char *data, CGameObject object, TImage *image)
{     
        drawVGATiles(data, frmDynamicCplVGA->spnDataStart->Value, object.objectSize, Point(frmDynamicCplVGA->spnWidth->Value, frmDynamicCplVGA->spnHeight->Value), Point(0, 0), crashPalette, frmDynamicCplVGA->chkReverse->Checked, frmDynamicCplVGA->spnMaxWidth->Value);
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
