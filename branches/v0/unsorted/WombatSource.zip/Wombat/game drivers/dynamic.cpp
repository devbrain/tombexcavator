//---------------------------------------------------------------------------


#pragma hdrstop

#include "dynamic.h"

#include <iostream>

#include "dynamicCpl.h"

using namespace std;

AnsiString CWGame_Dynamic::getFileExtensions()
{
        return "*.*";
}

CGameObject CWGame_Dynamic::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoImage;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        ifstream file(object.fileName.c_str(), ios::in | ios::binary);
        file.seekg(0, ios::end);
        result.objectSize = file.tellg();
        file.close();

        return result;
}

void CWGame_Dynamic::drawImage(char *data, CGameObject object, TImage *image)
{
        EDrawPriority drawP = edpWidth;
        if (frmDynamicCpl->rdbPlanar->Checked)  drawP = edpPlane;
        else
        if (frmDynamicCpl->rdbHeight->Checked)  drawP = edpHeight; 

        drawEGATiles(data, frmDynamicCpl->spnDataStart->Value, (frmDynamicCpl->spnLength->Value == 0)?(object.objectSize):(frmDynamicCpl->spnLength->Value + frmDynamicCpl->spnDataStart->Value), frmDynamicCpl->chkTransparent->Checked, Point(frmDynamicCpl->spnWidth->Value, frmDynamicCpl->spnHeight->Value), Point(0, 0), frmDynamicCpl->spnMaxWidth->Value, frmDynamicCpl->chkReverse->Checked, drawP, defaultPalette);

}

//---------------------------------------------------------------------------

#pragma package(smart_init)
