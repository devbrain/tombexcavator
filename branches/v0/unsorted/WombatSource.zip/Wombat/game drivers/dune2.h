//---------------------------------------------------------------------------

#ifndef dune2H
#define dune2H
#include "wombatCommon.h"

struct CWGame_Dune2: public CSimpleExtractor {
        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "Viewers not written yet, extract is OK";};
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);

        virtual CGameObject startUnpack(AnsiString fileName);
        virtual CGameObject nextUnpack();
};
//---------------------------------------------------------------------------
#endif
