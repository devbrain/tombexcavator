//---------------------------------------------------------------------------


#pragma hdrstop

#include "clyde2.h"

#include <iostream>

using namespace std;

struct CClyde2Header{
        char cFilename[17];
        unsigned nOffset;
        unsigned nLength;
};

CGameObject CWGame_Clyde2::startUnpack(AnsiString fileName)
{
        lastUnpackAttempt.open(fileName.c_str(), std::ios::in | std::ios::binary);
        lastUnpackName = fileName;
        lastUnpackAttempt.read((char*)&fileCount, sizeof(unsigned int));
        currentFile = 0;
        return nextUnpack();
}

CGameObject CWGame_Clyde2::nextUnpack()
{
        CClyde2Header header;

        CGameObject result;
        result.inPack = true;

        if (currentFile == fileCount)
        {
                lastUnpackAttempt.close();
                result.objectType = egoNone;
                return result;
        }


        lastUnpackAttempt.read((char*)&header.cFilename, 16);
        header.cFilename[16] = '\0';
        lastUnpackAttempt.read((char*)&header.nOffset, sizeof(unsigned));
        lastUnpackAttempt.read((char*)&header.nLength, sizeof(unsigned));

        result.objectName = ((AnsiString)header.cFilename).LowerCase();
        result.positionInFile = header.nOffset;
        result.objectSize = header.nLength;
        result.fileName = lastUnpackName;

        result.objectType = processFile(result).objectType;

        currentFile++;

        return result;
}

AnsiString CWGame_Clyde2::getName()
{
        return "Clyde's Revenge";
}

AnsiString CWGame_Clyde2::getFileExtensions()
{
        return "*.db";
}

CGameObject CWGame_Clyde2::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        if (result.objectName == "c2.db")
        {
                result.objectType = egoPacked;
                return result;
        }

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (extension == ".pcx")
                result.objectType = egoImage;
        else
        if (extension == ".voc")
                result.objectType = egoSound;
        else
        if (extension == ".mid")
                result.objectType = egoMusic;
        else
        if (extension == ".doc")
                result.objectType = egoText;
        else
        if (object.objectSize == 4000)
                result.objectType = egoDOSScreen;
        return result;
}

void CWGame_Clyde2::drawImage(char *data, CGameObject object, TImage *image)
{
        drawPCX(data, object.objectSize);
}


//---------------------------------------------------------------------------

#pragma package(smart_init)
