//---------------------------------------------------------------------------


#pragma hdrstop

#include "redwoodEd.h"

#include <iostream>

struct CRedwoodEdHeader {
        char zero; //always \0
        char name[12];
        short unknowns;
        unsigned int offset, length;
        int unknownI;
};

using namespace std;

AnsiString CWGame_RedwoodEd::getName()
{
        return "Redwood Educational";
}

AnsiString CWGame_RedwoodEd::getFileExtensions()
{
        return "mr*.*";
}

CGameObject CWGame_RedwoodEd::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        if ((object.objectName.Length() == 5) &&
        ((object.objectName[object.objectName.Length()] == '1') || (object.objectName[1] == 'w') && (object.objectName[object.objectName.Length()] == '2')))
        {
                result.objectType = egoPacked;
                return result;
        }

        ifstream file(object.fileName.c_str(), ios::in | ios::binary);
        file.seekg(0, ios::end);
        result.objectSize = file.tellg();
        file.close();

        if ((object.inPack) && (object.objectName.SubString(object.objectName.Length()-2, 3) != ".wr"))
                result.objectType = egoImage;
        else
        if ((object.objectName[1] == 'm') && (object.objectName.Length() == 5) && (object.objectName[object.objectName.Length()] == '8'))
                result.objectType = egoSound;
        else
        if ((object.objectName.Length() == 5) && (object.objectName[object.objectName.Length()] == '3'))
                result.objectType = egoText;
                
        return result;
}

void CWGame_RedwoodEd::drawImage(char *data, CGameObject object, TImage *image)
{
        switch (object.objectType){
        case egoImage: drawPCX(data, object.objectSize);
                        break;
        }

}

CGameObject CWGame_RedwoodEd::startUnpack(AnsiString fileName)
{
        lastUnpackAttempt.open(fileName.c_str(), std::ios::in | std::ios::binary);
        lastUnpackName = fileName;
        lastUnpackAttempt.seekg(128);
        hadFirst = false;
        firstDataStart = -1;
        return nextUnpack();
}

CGameObject CWGame_RedwoodEd::nextUnpack()
{
        CRedwoodEdHeader header;

        CGameObject result;
        result.inPack = true;

        if ((unsigned)lastUnpackAttempt.tellg() == firstDataStart)
        {
                lastUnpackAttempt.close();
                result.objectType = egoNone;
                return result;
        }


        lastUnpackAttempt.read(&header.zero, 1);
        lastUnpackAttempt.read((char*)&header.name, 11);
        header.name[11] = '\0';
        lastUnpackAttempt.read((char*)&header.unknowns, sizeof(short));
        lastUnpackAttempt.read((char*)&header.offset, sizeof(unsigned));
        lastUnpackAttempt.read((char*)&header.length, sizeof(unsigned));
        lastUnpackAttempt.read((char*)&header.unknownI, sizeof(int));

        result.objectName = ((AnsiString)header.name).LowerCase();
        result.positionInFile = header.offset;
        result.objectSize = header.length;
        result.fileName = lastUnpackName;

        result.objectType = processFile(result).objectType;

        if (!hadFirst)
        {
                hadFirst = true;
                firstDataStart = header.offset;
        }

        return result;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)

