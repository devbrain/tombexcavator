//---------------------------------------------------------------------------

#ifndef cannonH
#define cannonH
#include "wombatCommon.h"

struct CWGame_Cannon: public CSimpleExtractor {
        virtual AnsiString getName();
        virtual AnsiString getFileExtensions();
        virtual AnsiString getCredits() {return "Does not work, data is possibly compressed";};
        virtual CGameObject processFile(CGameObject object);
        virtual void drawImage(char *data, CGameObject object, TImage *image);

        virtual CGameObject startUnpack(AnsiString fileName);
        virtual CGameObject nextUnpack();

        unsigned long dataStart;
};
//---------------------------------------------------------------------------
#endif
