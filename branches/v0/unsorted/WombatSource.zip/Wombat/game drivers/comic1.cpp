//---------------------------------------------------------------------------


#pragma hdrstop

#include "comic1.h"

#include <iostream>

using namespace std;

AnsiString CWGame_Comic1::getName()
{
        return "Captain Comic 1";
}

AnsiString CWGame_Comic1::getFileExtensions()
{
        return "*.ega;*.shp";
}

CGameObject CWGame_Comic1::processFile(CGameObject object)
{
        CGameObject result;
        result.objectType = egoOther;
        result.fileName = object.fileName;
        result.objectName = object.objectName;

        ifstream file(object.fileName.c_str(), ios::in | ios::binary);
        file.seekg(0, ios::end);
        result.objectSize = file.tellg();
        file.close();

        AnsiString extension = object.objectName.SubString(object.objectName.Length()-3, 4);

        if (extension == ".ega")
                result.objectType = egoFullscreen;
        else
        if (extension == ".shp")
                result.objectType = egoSprite;
        if (extension == ".tt2")
                result.objectType = egoBackTile;

        return result;
}

void CWGame_Comic1::drawImage(char *data, CGameObject object, TImage *image)
{
        char tempCopy[32];
        switch (object.objectType){
        case egoFullscreen: drawEGANoProcess(data, 0, 4, Point(320, 200), Point(0, 0), false, edpPlane, defaultPalette); break;
        case egoSprite: for (unsigned i = 0; i < (unsigned)(object.objectSize / 160); i++)
                        {
                                memcpy((void*)&tempCopy[0], (void*)&data[i*160], 32);
                                memcpy((void*)&data[i*160], (void*)&data[i*160 + 128], 32);
                                memcpy((void*)&data[i*160 + 128], (void*)&tempCopy[0], 32);
                        }
                        drawEGATiles(data, 0, object.objectSize, true, Point(16, 16), Point(0, 0), 320, false, edpPlane, defaultPalette);
                        break;
        case egoBackTile: drawEGATiles(data, 0, object.objectSize, false, Point(16, 16), Point(0, 0), 320, false, edpPlane, defaultPalette);
        }

}

int CWGame_Comic1::unpackFileFromPack(CGameObject object, char* &buffer)
{
        return 0;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
