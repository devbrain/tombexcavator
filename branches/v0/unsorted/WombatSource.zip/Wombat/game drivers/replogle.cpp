//---------------------------------------------------------------------------


#pragma hdrstop

#include "replogle.h"
#include <iostream>

using namespace std;

struct CReplogleHeader{
        char cFilename[13];
        unsigned nOffset;
        unsigned nLength;
};

CGameObject CWExtractor_Replogle::startUnpack(AnsiString fileName)
{
        lastUnpackAttempt.open(fileName.c_str(), ios::in | ios::binary);
        lastUnpackName = fileName;
        return nextUnpack();
}           

CGameObject CWExtractor_Replogle::nextUnpack()
{
        CReplogleHeader header;

        CGameObject result;
        result.inPack = true;

        lastUnpackAttempt.read((char*)&header.cFilename, 12);
        header.cFilename[12] = '\0';
        lastUnpackAttempt.read((char*)&header.nOffset, sizeof(unsigned));
        lastUnpackAttempt.read((char*)&header.nLength, sizeof(unsigned));

        if ((header.nOffset == 0) || (header.nLength == 0))
        {
                lastUnpackAttempt.close();
                result.objectType = egoNone;
                return result;
        }

        result.objectName = ((AnsiString)header.cFilename).LowerCase();
        result.positionInFile = header.nOffset;
        result.objectSize = header.nLength;
        result.fileName = lastUnpackName;

        result.objectType = processFile(result).objectType;

        //result.objectName = result.objectName +  "(" + IntToStr(header.nLength) + ")";

        return result;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
