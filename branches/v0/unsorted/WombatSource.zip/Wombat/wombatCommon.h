//---------------------------------------------------------------------------

#ifndef wombatCommonH
#define wombatCommonH

#include <fstream>
#include <comctrls.hpp>
#include <vector>

struct TRGB {unsigned char R, G, B; TRGB(UCHAR r, UCHAR g, UCHAR b){R = r; G = g; B = b;} TRGB(){R = G = B = 0;} };

extern TRGB defaultPalette[16];
extern TRGB crashPalette[256];
        

enum EGameObjectType {egoNone, egoPacked, egoText, egoImage, egoSprite, egoBackTile, egoForeTile, egoFullscreen, egoLevel, egoSound, egoMusic, egoDOSScreen, egoOther, egoHidden, egoLevelData, egoLastFolder, egoPCSound, egoLast};
enum EDrawPriority {edpPlane, edpHeight, edpWidth};
enum ESoundType {wsndOther, wsndSnd, wsndVoc, wsndWav};
enum EMusicType {wmusOther, wmusIMF, wmusMID};

struct CGameObject {
        AnsiString objectName, fileName;
        unsigned positionInFile;
        unsigned objectSize;
        EGameObjectType objectType;
        bool inPack;
        int extraData;
        CGameObject(){inPack = false; extraData = 0;};
};

class IWombatGame {
        public:
        virtual AnsiString getName() = 0;
        virtual AnsiString getFileExtensions() = 0;
        virtual AnsiString getCredits() = 0;
        virtual CGameObject processFile(CGameObject object) = 0;
        virtual CGameObject startUnpack(AnsiString fileName) = 0;
        virtual CGameObject nextUnpack() = 0;
        virtual ESoundType soundType(CGameObject object) {return wsndOther;};
        virtual EMusicType musicType(CGameObject object) {return wmusOther;};

        //level things
        virtual bool canViewLevel(){return false;};
        virtual void initLevel(CGameObject object){};
        virtual void drawLevel(TPoint offset){};
        void imageToBitmap(CGameObject object, Graphics::TBitmap *bitmap);
        virtual int getLevelWidth(){return 0;};
        virtual int getLevelHeight(){return 0;};

        //file-open things
        virtual int unpackFileFromPack(CGameObject object, char* &buffer) = 0;
        CGameObject findObject(AnsiString name, int extraData);
        void loadFile(AnsiString fileName, bool justThisFile);
        void loadDirectory(AnsiString directoryName);
        void viewFile(CGameObject object);

        static void createCrashPalette();

        //VGA drawing functions
        void drawVGATiles(char *data, int dataStart, int dataSize, TPoint size, TPoint location, TRGB palette[], bool colsFirst, int maxWidth);
        void drawVGAImage(char *data, int dataStart, TPoint size, TPoint location, TRGB palette[]);
        void drawVGAImageColumn(char *data, int dataStart, TPoint size, TPoint location, TRGB palette[]);
        void drawVGAInterlaced(char *data, int dataStart, int frames, TPoint size, TPoint location, TRGB palette[]);

        //EGA drawing functions
        void drawEGAImage(char ** data, int planes, TPoint size, TPoint location, bool reverseTrans, TRGB palette[]);
        void drawEGANoProcess(char *data, int dataStart, int planes, TPoint size, TPoint location, bool reverseTrans, EDrawPriority planePriority, TRGB palette[]);
        void drawEGATiles(char * data, int dataStart, int dataSize, bool transparent, TPoint size, TPoint location, int maxWidth, bool reverseTrans, EDrawPriority planePriority, TRGB palette[]);

        //PCX
        void drawPCX(char * data, int size);

        //other drawing functions
        void drawPalette(TRGB palette[], short paletteSize);
        void drawDOSScreen(char * data);
        unsigned char FbitColorTo8bit(unsigned char in){return ((in == 64) ? 255 : in << 2);};
        virtual void drawImage(char *data, CGameObject object, TImage *image) = 0;

};

struct CSimpleExtractor: public IWombatGame {
        virtual int unpackFileFromPack(CGameObject object, char* &buffer);    

        std::ifstream lastUnpackAttempt;
        AnsiString lastUnpackName;
};

inline unsigned char bitFromChar(UCHAR c, int bitToGet)
        {return (c & (1 << bitToGet)) >> bitToGet;};
//---------------------------------------------------------------------------
#endif
