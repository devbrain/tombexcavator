//---------------------------------------------------------------------------

#ifndef titleH
#define titleH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TfrmTitle : public TForm
{
__published:	// IDE-managed Components
        TImage *Image1;
        TTimer *Timer1;
        TBevel *Bevel1;
        TLabel *Label1;
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TfrmTitle(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmTitle *frmTitle;
//---------------------------------------------------------------------------
#endif
