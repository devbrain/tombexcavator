//---------------------------------------------------------------------------


#pragma hdrstop

#include "sndPlayer.h"
#include "main.h"
#include <mmsystem.h>
#include <math.h>

struct CSNDHeader {
        char ID[4]; //SND\0
        unsigned short fileLength, soundCount, unknown; //soundCount = (0x3f in Keen 1)
        char unknownZeroes[6];
};

//0x400   2   data for sound #1 begins here... (Keen 1)

struct CSNDSoundHeader {
        unsigned short offset;
        unsigned char priority, exists;
        char name[12];
};

int short_while = 44100/128;
double freqdiv = 1193180.0;

double t = 0.0;
double dt = 1.0/44100.0;

TMemoryStream *stream = NULL;

void loadSndFromMemory(char * file, int size)
{
        frmMain->lstPCSound->Items->Clear();

        if (!stream)
                stream = new TMemoryStream();
        stream->Clear();
        stream->Write((void*)file, size);
        stream->Position = 0;

        CSNDHeader header;
        stream->Read((void*)&header, sizeof(header));

        if (((AnsiString)header.ID).UpperCase() != "SND")
                return;

        CSNDSoundHeader soundHeader;

        for (int i = 0; i < header.soundCount; i++)
        {
                stream->Read((void*)&soundHeader, sizeof(soundHeader));
                frmMain->lstPCSound->Items->Add(((AnsiString)soundHeader.name).LowerCase());
        }

}

void writeFrequency (int freq, char* data, unsigned &dataPoint)
  {
    /*  write a short while of 'freq':  */
    /*  y = Amplitude * sin (omega * t)  where omega = 2*PI*freq  */

    double y;
    int b,b1,b2;
    int j;

    for (j = 0; j < short_while; j++)
      {
	if (freq)
		y = 5000.0 * sin (2.0 * M_PI * freqdiv / (double)freq * t);
	else
		y = 0.0;

        if (y > 1) y = 5000;
        if (y < 1) y = -5000;

	t = t + dt;
	b = y;
	b1 = b & 255;
	b2 = b / 256;
     	data[dataPoint++] = b1;
	data[dataPoint++] = b2;   
      }
  }


void playSound(int sound, bool soundcard)
{
        CSNDSoundHeader soundHeader;
        stream->Position = sizeof(CSNDHeader) + (sound * sizeof(CSNDSoundHeader));
        stream->Read((void*)&soundHeader, sizeof(soundHeader));
        stream->Position = soundHeader.offset;

        //create the sound
        int dataSize = 0;
        unsigned short freq;
        stream->Read((void*)&freq, sizeof(freq));
        while (freq != 0xFFFF)
        {
                stream->Read((void*)&freq, sizeof(freq));
                dataSize += short_while * 2;
        }

        char * pData = new char[dataSize];

        stream->Position = soundHeader.offset;

        unsigned pDatLocation = 0;

        stream->Read((void*)&freq, sizeof(freq));
        while (freq != 0xFFFF)
        {
                writeFrequency(freq, pData, pDatLocation);
                stream->Read((void*)&freq, sizeof(freq));
        }

        //play it
        // Prepare a WAVEFORMATEX required for opening the device driver
        HWAVEOUT    hWaveOut;
        WAVEHDR     sWaveHdr;

        WAVEFORMATEX sWaveFormat;
        sWaveFormat.wFormatTag           = WAVE_FORMAT_PCM;
        sWaveFormat.nChannels            = 1;
        sWaveFormat.nSamplesPerSec       = 44100;
        sWaveFormat.nAvgBytesPerSec      = 44100;
        sWaveFormat.nBlockAlign          = 1;
        sWaveFormat.wBitsPerSample       = 16;
        sWaveFormat.cbSize               = sizeof(WAVEFORMATEX);

        // Try to open the device driver
        MMRESULT Result = waveOutOpen( &hWaveOut, WAVE_MAPPER, &sWaveFormat,
                                  (ULONG)frmMain->Handle, 0,
                                  CALLBACK_WINDOW );
        if ( Result != MMSYSERR_NOERROR )
        {
                hWaveOut = 0;
                return;
        }

        // Prepare the header
        sWaveHdr.lpData            = pData;
        sWaveHdr.dwBufferLength    = pDatLocation;
        sWaveHdr.dwFlags           = 0;
        sWaveHdr.dwLoops           = 0;
        waveOutPrepareHeader( hWaveOut, &sWaveHdr, sizeof(sWaveHdr) );

        // Play the file
        //boPlaying = true;
        waveOutWrite( hWaveOut, &sWaveHdr, sizeof(sWaveHdr) );

        while(waveOutUnprepareHeader(hWaveOut, &sWaveHdr, sizeof(sWaveHdr)) == WAVERR_STILLPLAYING);

        delete [] pData;
        pData = NULL;
        waveOutClose( hWaveOut ); 
}

void cleanUpSount()
{
        if (stream)
                delete stream;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
