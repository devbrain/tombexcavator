//---------------------------------------------------------------------------
//ADD TO TREEVIEW WILL FAIL ON PCSPEAKER

#pragma hdrstop

#include "wombatCommon.h"
#include "main.h"
#include "sndplayer.h"    
#include <iostream>
#include <pcxctrl.hpp>

using namespace std;

TRGB defaultPalette[16] =  {TRGB(0, 0, 0),          TRGB(0, 0, 0xA8),       TRGB(0, 0xA8, 0),       TRGB(0, 0xA8, 0xA8),    TRGB(0xA8, 0, 0),       TRGB(0xA8, 0, 0xA8),    TRGB(0xA8, 0x54, 0),    TRGB(0xA8, 0xA8, 0xA8),
                            TRGB(0x54, 0x54, 0x54), TRGB(0x54, 0x54, 0xFC), TRGB(0x54, 0xFC, 0x54), TRGB(0x54, 0xFC, 0xFC), TRGB(0xFC, 0x54, 0x54), TRGB(0xFC, 0x54, 0xFC), TRGB(0xFC, 0xFC, 0x54), TRGB(0xFC, 0xFC, 0xFC)};
TRGB crashPalette[256];

TRGB transColor(0, 0xFF, 0);

TTreeNode * topLevelNodes[egoLastFolder];

const AnsiString folderNames[] = {"none", "packed", "texts", "images", "sprites", "back tiles", "fore tiles", "fullscreen images", "levels", "sound", "music", "DOS screen", "other", "hidden", "level-data"};

void addTreeviewFolders(TTreeNode *parent)
{
        TTreeNode *temp;
        for (int i = 0; i < (int)egoLastFolder; i++)
        {
                        temp = frmMain->trvGame->Items->AddChild(parent, folderNames[i]);
                        temp->ImageIndex = (int)egoPacked + 1;
                        if (!parent) //top-level
                                topLevelNodes[i] = temp;
        }
}

void clearTreeviewFolders()
{
        int i = 0;
        while (i < frmMain->trvGame->Items->Count)
        {
                if ((frmMain->trvGame->Items->Item[i]->ImageIndex == (int)egoPacked + 1) && (frmMain->trvGame->Items->Item[i]->Count == 0))
                        frmMain->trvGame->Items->Delete(frmMain->trvGame->Items->Item[i]);
                else
                        i++;
        }
}

TTreeNode *addObjectToTreeView(CGameObject object, TTreeNode *parent)
{
        if (object.objectType == egoHidden)
                return NULL;
        TTreeNode *result = frmMain->trvGame->Items->AddChild(parent, object.objectName.LowerCase());
        result->ImageIndex = ((int)object.objectType) + 1;
        result->SelectedIndex = ((int)object.objectType) + 1;
        if (object.objectType == egoPacked)
                result->Data = NULL;
        else
        {
                result->Data = new CGameObject;
                *((CGameObject*)result->Data) = object;
        }
        return result;
}

void IWombatGame::loadFile(AnsiString fileName, bool justThisFile)
{
        if (justThisFile)
        {
                frmMain->clearTreeView();
                frmMain->trvGame->Items->Clear();
                addTreeviewFolders(NULL);
        }
        CGameObject in;
        in.fileName = fileName.LowerCase();
        in.objectName = ExtractFileName(fileName.LowerCase());
        CGameObject returnedObject = processFile(in);
        if (returnedObject.objectType == egoPacked)
        {
                TTreeNode *parentNode = addObjectToTreeView(returnedObject, NULL);
                addTreeviewFolders(parentNode);
                returnedObject = startUnpack(fileName);
                while (returnedObject.objectType != egoNone)
                {
                        addObjectToTreeView(returnedObject, parentNode->Item[(int)returnedObject.objectType]);
                        returnedObject = nextUnpack();
                }
        }
        else
        addObjectToTreeView(returnedObject, topLevelNodes[(int)returnedObject.objectType]);
        if (justThisFile) //clean up treeview
                clearTreeviewFolders();
}

void IWombatGame::loadDirectory(AnsiString directoryName)
{
        frmMain->clearTreeView();
        frmMain->trvGame->Items->Clear();
        addTreeviewFolders(NULL);
        //go through all files supported, loadFile each
        TSearchRec SearchRec;
        int nStatus;
        AnsiString s = directoryName + "\\*.*";
        nStatus = FindFirst(s.c_str(), 0, SearchRec);
        while (nStatus == 0)
        {    
                loadFile(directoryName + '\\' + SearchRec.Name, false);
                nStatus = FindNext(SearchRec);
        }
        FindClose(SearchRec);
        clearTreeviewFolders();
}

void IWombatGame::imageToBitmap(CGameObject object, Graphics::TBitmap *bitmap)
{
        viewFile(object);
        bitmap->Width = frmMain->imgImage->Picture->Bitmap->Width;
        bitmap->Height = frmMain->imgImage->Picture->Bitmap->Height;
        bitmap->Canvas->CopyRect(Rect(0, 0, bitmap->Width, bitmap->Height), frmMain->imgImage->Picture->Bitmap->Canvas, Rect(0, 0, bitmap->Width, bitmap->Height));
        frmMain->spnPlanesChange(NULL);
}

void IWombatGame::viewFile(CGameObject object)
{
        frmMain->imgImage->Visible = false;
        frmMain->mmoText->Visible = false;
        frmMain->pnlLevel->Visible = false;
        frmMain->pnlSpeakerSound->Visible = false;
        frmMain->btnSaveImage->Enabled = false;
        frmMain->lblSaveImage->Enabled = false;
        bitmapSize = Point(0, 0);
        if (currentData)
        {
                delete [] currentData;
                currentData = NULL;
                currentDataSize = 0;
        }
        
        if (object.inPack) //unpack it
                currentDataSize = unpackFileFromPack(object, currentData);
        else
        {
                currentData = new char[object.objectSize];
                ifstream file(object.fileName.c_str(), ios::in | ios::binary);
                file.read(currentData, object.objectSize);
                file.close();
                currentDataSize = object.objectSize;
        }

        if (currentDataSize == 0)
                return;

        if ((object.objectType == egoText) || (object.objectType == egoOther))
        {
                frmMain->mmoText->Visible = true;
                if (object.inPack)
                        frmMain->mmoText->Lines->Text = (AnsiString)currentData;
                else
                        frmMain->mmoText->Lines->LoadFromFile(object.fileName);
        }
        else
        if ((object.objectType == egoBackTile) || (object.objectType == egoForeTile) ||
            (object.objectType == egoSprite) || (object.objectType == egoFullscreen) ||
            (object.objectType == egoImage) || (object.objectType == egoDOSScreen))
        {
                frmMain->imgImage->Visible = true;
                frmMain->btnSaveImage->Enabled = true;
                frmMain->lblSaveImage->Enabled = true;
                bitmapSize = Point(0, 0);
                frmMain->imgImage->Top = 0;
                frmMain->imgImage->Width = frmMain->pnlMain->Width;
                frmMain->imgImage->Height = frmMain->pnlMain->Height;
                frmMain->imgImage->Picture->Bitmap->Width = frmMain->imgImage->Width;
                frmMain->imgImage->Picture->Bitmap->Height = frmMain->imgImage->Height;
                frmMain->imgImage->Picture->Bitmap->Canvas->Brush->Color = (TColor)0xC0DCC0;
                frmMain->imgImage->Picture->Bitmap->Canvas->FillRect(Rect(0,0,frmMain->imgImage->Width, frmMain->imgImage->Height));
                if (object.objectType == egoDOSScreen)
                         drawDOSScreen(currentData);
                else
                {
                        drawImage(currentData, object, frmMain->imgImage);

                        frmMain->imgImage->Picture->Bitmap->Width = bitmapSize.x;
                        frmMain->imgImage->Width = bitmapSize.x;
                        frmMain->imgImage->Picture->Bitmap->Height = bitmapSize.y;
                        frmMain->imgImage->Height = bitmapSize.y;
                        if (frmMain->imgImage->Height > frmMain->pnlMain->Height)
                                frmMain->cSpinImage->Visible = true;
                        else
                                frmMain->cSpinImage->Visible = false;
                }

                frmMain->imgImage->Repaint();
        }
        else
        if (object.objectType == egoSound)
        {
                if (soundType(object) == wsndSnd)
                {
                        frmMain->pnlSpeakerSound->Visible = true;
                        loadSndFromMemory(currentData, object.objectSize);
                        isSound = true;
                }
        }
        else
        if (object.objectType == egoMusic)
        {
                if (musicType(object) == wmusMID)
                {
                        frmMain->pnlSpeakerSound->Visible = true;
                        isSound = false;
                }
        }
        else
        if ((object.objectType == egoLevel) && (canViewLevel()))
        {
                frmMain->pnlLevel->Visible = true;
        }
}

void IWombatGame::createCrashPalette()
{
        crashPalette[0] = TRGB(0, 0, 0);
        for (int i = 1; i < 256; i++)
                crashPalette[i] = TRGB(random(256), random(256), random(256));
}

void IWombatGame::drawVGATiles(char *data, int dataStart, int dataSize, TPoint size, TPoint location, TRGB palette[], bool colsFirst, int maxWidth)
{
        int currentFrame = 0;

        int tilesToWidth = maxWidth / size.x;

        while (dataStart + (currentFrame * size.x * size.y) < dataSize)
        {
                if (colsFirst)
                        drawVGAImageColumn(data, dataStart + (currentFrame * size.x * size.y), size, Point(location.x+(currentFrame % tilesToWidth) * size.x, location.y+(currentFrame / tilesToWidth) * size.y), palette);
                else
                        drawVGAImage(data, dataStart + (currentFrame * size.x * size.y), size, Point(location.x+(currentFrame % tilesToWidth) * size.x, location.y+(currentFrame / tilesToWidth) * size.y), palette);
                currentFrame++;
        }
}

void IWombatGame::drawVGAInterlaced(char *data, int dataStart, int frames, TPoint size, TPoint location, TRGB palette[])
{
        UCHAR * scanPoint;
        UCHAR dataValue;

        for (int y = 0; y < size.y; y++)
        {

                if (y + location.y < frmMain->imgImage->Picture->Bitmap->Height)
                        scanPoint = (UCHAR*)frmMain->imgImage->Picture->Bitmap->ScanLine[y + location.y];
                else
                        break;

                for (int x = 0; x < size.x; x++)
                        for (int i = 0; i < frames; i++)
                        {
                                if ((x * frames) + i + location.x >= frmMain->imgImage->Picture->Bitmap->Width)
                                        break;
                                dataValue = data[dataStart + (i * size.x * size.y) + (y * size.x) + x];
                                scanPoint[((x * frames) + i + location.x)*3] = palette[dataValue].B;
                                scanPoint[((x * frames) + i + location.x)*3 + 1] = palette[dataValue].G;
                                scanPoint[((x * frames) + i + location.x)*3 + 2] = palette[dataValue].R;
                        }
        }
        bitmapSize.x = size.x * frames;
        bitmapSize.y = size.y;
}

void IWombatGame::drawVGAImage(char *data, int dataStart, TPoint size, TPoint location, TRGB palette[])
{
        UCHAR * scanPoint;
        UCHAR dataValue;

        if (bitmapSize.x < location.x + size.x)
                        bitmapSize.x = location.x + size.x;
        if (bitmapSize.y < location.y + size.y)
        {
                        bitmapSize.y = location.y + size.y;
                        if (frmMain->imgImage->Picture->Bitmap->Height < bitmapSize.y)
                        {
                                frmMain->imgImage->Picture->Bitmap->Height = bitmapSize.y;
                                frmMain->imgImage->Height = bitmapSize.y;
                        }
        }

        for (int y = 0; y < size.y; y++)
        {

                if (y + location.y < frmMain->imgImage->Picture->Bitmap->Height)
                        scanPoint = (UCHAR*)frmMain->imgImage->Picture->Bitmap->ScanLine[y + location.y];
                else
                        break;

                for (int x = 0; x < size.x; x++)
                {
                        if (x + location.x >= frmMain->imgImage->Picture->Bitmap->Width)
                                        break;
                        dataValue = data[dataStart + y * size.x + x];
                        scanPoint[(x + location.x)*3] = palette[dataValue].B;
                        scanPoint[(x + location.x)*3 + 1] = palette[dataValue].G;
                        scanPoint[(x + location.x)*3 + 2] = palette[dataValue].R;
                }
        }
}

void IWombatGame::drawVGAImageColumn(char *data, int dataStart, TPoint size, TPoint location, TRGB palette[])
{
        UCHAR * scanPoint;
        UCHAR dataValue;

        if (bitmapSize.x < location.x + size.x)
                        bitmapSize.x = location.x + size.x;
        if (bitmapSize.y < location.y + size.y)
        {
                        bitmapSize.y = location.y + size.y;
                        if (frmMain->imgImage->Picture->Bitmap->Height < bitmapSize.y)
                        {
                                frmMain->imgImage->Picture->Bitmap->Height = bitmapSize.y;
                                frmMain->imgImage->Height = bitmapSize.y;
                        }
        }

        for (int x = 0; x < size.x; x++)
        {
                if (x + location.x >= frmMain->imgImage->Picture->Bitmap->Width)
                        break;

                for (int y = 0; y < size.y; y++)
                {
                        if (y + location.y < frmMain->imgImage->Picture->Bitmap->Height)
                                scanPoint = (UCHAR*)frmMain->imgImage->Picture->Bitmap->ScanLine[y + location.y];
                        else
                                break;

                        dataValue = data[dataStart + x * size.y + y];
                        scanPoint[(x + location.x)*3] = palette[dataValue].B;
                        scanPoint[(x + location.x)*3 + 1] = palette[dataValue].G;
                        scanPoint[(x + location.x)*3 + 2] = palette[dataValue].R;
                }
        }
}

void IWombatGame::drawPalette(TRGB palette[], short paletteSize)
{
        for (int i = 0; i  < paletteSize; i++)
        {
                frmMain->imgImage->Picture->Bitmap->Canvas->Brush->Color = (TColor)RGB(palette[i].R, palette[i].G, palette[i].B);
                frmMain->imgImage->Picture->Bitmap->Canvas->Rectangle(i * 10, frmMain->imgImage->Picture->Bitmap->Height - 10, (i + 1)*10, frmMain->imgImage->Picture->Bitmap->Height);
        }
}

void IWombatGame::drawEGAImage(char ** data, int planes, TPoint size, TPoint location, bool reverseTrans, TRGB palette[])
{
        UCHAR * scanPoint;

        if (bitmapSize.x < location.x + size.x)
                        bitmapSize.x = location.x + size.x;
        if (bitmapSize.y < location.y + size.y)
        {
                        bitmapSize.y = location.y + size.y;
                        if (frmMain->imgImage->Picture->Bitmap->Height < bitmapSize.y)
                        {
                                frmMain->imgImage->Picture->Bitmap->Height = bitmapSize.y;
                                frmMain->imgImage->Height = bitmapSize.y;
                        }
        }

        if (planes < 5) //not transparent
                for (int y = 0; y < size.y; y++)
                {
                        if (y + location.y < frmMain->imgImage->Picture->Bitmap->Height)
                                scanPoint = (UCHAR*)frmMain->imgImage->Picture->Bitmap->ScanLine[y + location.y];
                        else
                                break;
                        for (int x = 0; x < size.x; x++)
                        {
                                if (x + location.x >= frmMain->imgImage->Picture->Bitmap->Width)
                                        break;
                                UCHAR finalEntry = 0;
                                for (int z = 0; z < planes; z++)
                                        finalEntry += data[z][y * size.x + x] << z;
                                scanPoint[(x + location.x)*3] = palette[finalEntry].B;
                                scanPoint[(x + location.x)*3 + 1] = palette[finalEntry].G;
                                scanPoint[(x + location.x)*3 + 2] = palette[finalEntry].R;
                        }
                }
        else
                for (int y = 0; y < size.y; y++)
                {
                        if (y + location.y < frmMain->imgImage->Picture->Bitmap->Height)
                                scanPoint = (UCHAR*)frmMain->imgImage->Picture->Bitmap->ScanLine[y + location.y];
                        else
                                break;
                        for (int x = 0; x < size.x; x++)
                        {
                                if (x + location.x >= frmMain->imgImage->Picture->Bitmap->Width)
                                        break;
                                UCHAR finalEntry = 0;
                                if (data[0][y * size.x + x] == (reverseTrans)?1:0)
                                {
                                        for (int z = 0; z < planes - 1; z++)
                                                finalEntry += data[z + 1][y * size.x + x] << z;
                                        scanPoint[(x + location.x)*3] = palette[finalEntry].B;
                                        scanPoint[(x + location.x)*3 + 1] = palette[finalEntry].G;
                                        scanPoint[(x + location.x)*3 + 2] = palette[finalEntry].R;
                                }
                                else
                                {
                                        scanPoint[(x + location.x) * 3] = transColor.B;
                                        scanPoint[(x + location.x) * 3 + 1] = transColor.G;
                                        scanPoint[(x + location.x) * 3 + 2] = transColor.R;
                                }
                        }
                }
        
}

void IWombatGame::drawEGANoProcess(char *data, int dataStart, int planes, TPoint size, TPoint location, bool reverseTrans, EDrawPriority planePriority, TRGB palette[])
{
        char ** plane = new char*[planes];
        int currentBit = -1;
        int currentWidthDat = 0;
        unsigned currentDat = dataStart;
        UCHAR fullDat = 0;
        unsigned aTemp;

        for (int plan = 0; plan < planes; plan++)
        {
                plane[plan] = new char[size.x * size.y];
                memset(plane[plan], size.x * size.y, 0);
        }

        switch (planePriority){
        case edpPlane:
                for (int plan = 0; plan < planes; plan++)
                        for (int j = 0; j < size.y; j++)
                                for (int i = 0; i < size.x; i++)
                                {
                                        if (currentBit == -1)
                                        {
                                                fullDat = data[currentDat++];
                                                currentBit = 7;
                                        }
                                        plane[plan][j * size.x + i] = bitFromChar(fullDat, currentBit--);
                                }
                 break;

        case edpHeight:
                for (int j = 0; j < size.y; j++)
                        for (int plan = 0; plan < planes; plan++)
                                for (int i = 0; i < size.x; i++)
                                {
                                        if (currentBit == -1)
                                        {
                                                fullDat = data[currentDat++];
                                                currentBit = 7;
                                        }
                                        plane[plan][j * size.x + i] = bitFromChar(fullDat, currentBit--);
                                }
                break;

        case edpWidth:
                for (int i = 0; i < (size.y * size.x / 8); i++)
                        for (int plan = 0; plan < planes; plan++)
                        {
                                fullDat = data[currentDat++];

                                for (int b = 7; b >= 0; b--)
                                        plane[plan][currentWidthDat + (7 - b)] = bitFromChar(fullDat, b);

                                if (plan == planes - 1)
                                        currentWidthDat += 8;
                        }
                break;
        }

        drawEGAImage(plane, planes, size, location, reverseTrans, palette);

        for (int z = 0; z < planes; z++)
                delete [] plane[z];

        delete [] plane;
}

void IWombatGame::drawEGATiles(char * data, int dataStart, int dataSize, bool transparent, TPoint size, TPoint location, int maxWidth, bool reverseTrans, EDrawPriority planePriority, TRGB palette[])
{
        int planes = (transparent)?5:4;

        int currentFrame = 0;

        int tilesToWidth = maxWidth / size.x;

        while (dataStart + (currentFrame * planes * size.x * size.y / 8) < dataSize)
        {
                drawEGANoProcess(data, dataStart + (currentFrame * planes * size.x * size.y / 8), planes, size, Point(location.x + ((currentFrame % tilesToWidth) * size.x), location.y + ((currentFrame  / tilesToWidth) * size.y)), reverseTrans, planePriority, palette);
                currentFrame++;
        }

}

int CSimpleExtractor::unpackFileFromPack(CGameObject object, char* &buffer)
{
        ifstream filein(object.fileName.c_str(), ios::in | ios::binary);
        filein.seekg(object.positionInFile);

        buffer = new char[object.objectSize + 1];
        buffer[object.objectSize] = '\0';
        filein.read(buffer, object.objectSize);

        return object.objectSize;
}

void IWombatGame::drawDOSScreen(char * data)
{
        for (int y = 0; y < 25; y++)
                for (int x = 0; x < 80; x++)
                        frmMain->imgImage->Picture->Bitmap->Canvas->TextOut(x * 7, y * 13, (AnsiString)((char)data[(y * 160) + (x * 2)]));
}

CGameObject IWombatGame::findObject(AnsiString name, int extraData)
{    
        CGameObject * object;
        CGameObject result;
        result.objectType = egoNone;
        for (int i = 0; i < frmMain->trvGame->Items->Count; i++)
        {
                if (frmMain->trvGame->Items->Item[i]->Count == 0)
                {
                        object = (CGameObject *)frmMain->trvGame->Items->Item[i]->Data;
                        if ( (name == object->objectName) && (extraData == object->extraData))
                                return *object;
                }
        }
        return result;
}

void IWombatGame::drawPCX(char * data, int size)
{
        TMemoryStream *stream = new TMemoryStream;
        stream->Write((void*)data, size);

        TPCXBitmap *PCXBitmap = new TPCXBitmap;
        PCXBitmap->LoadFromStream(stream);

        frmMain->imgImage->Picture->Bitmap->Width = PCXBitmap->Width;
        frmMain->imgImage->Picture->Bitmap->Height = PCXBitmap->Height;
        TRect rect = Rect(0, 0, PCXBitmap->Width, PCXBitmap->Height);
        frmMain->imgImage->Picture->Bitmap->Canvas->CopyRect(rect, PCXBitmap->Canvas, rect);
        bitmapSize = Point(PCXBitmap->Width, PCXBitmap->Height);

        delete PCXBitmap;
        delete stream;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
