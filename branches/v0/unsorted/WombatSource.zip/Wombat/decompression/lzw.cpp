//---------------------------------------------------------------------------


#pragma hdrstop

#include "lzw.h"
#include <vector>
#include <system.hpp>
#include <math.h>

using namespace std;


int unLZW(char * source, char * dest, int sizeSource, int sizeDest, int startBitBase, int maxBitBase, bool resetOnEnd, int firstUsedEntry)
{
        vector<AnsiString> stringTable;

     //   std::vector<bool> specialCase;
     //   stringTable.reserve(4096);
        for (int i = 0; i < 256; i++)
        //{
                stringTable.push_back((AnsiString)((char)i));
                //specialCase.push_back(false);
        //}

        unsigned nextEntry = firstUsedEntry;
        int bitBase = startBitBase;
        unsigned result;

        int currentDPos = 0;
        int currentSPos = 4;

        unsigned nextBitChange = 512;

        int aCount;

        AnsiString currentString, newString;

        unsigned long inputBuffer = 0;
        bool stillInRange = true;
        bool addEntries = true;
        int spaceFreeInIB = 0;
        for (int i = 0; i < 4; i++)
                inputBuffer = inputBuffer + (unsigned)(((unsigned)((UCHAR)source[i])) << (i * 8));

        //frmMonsterBash->Memo2->Lines->Clear();

        while (stillInRange || (!stillInRange && (spaceFreeInIB > bitBase)))/*(currentSPos < sizeSource)*/
        {

                while (spaceFreeInIB > 8) //move new data in
                {
                        if (currentSPos < sizeSource)
                                inputBuffer += ((unsigned)((UCHAR)source[currentSPos++])) << (32 - spaceFreeInIB);
                        else
                        {
                                stillInRange = false;
                                spaceFreeInIB -= 8;
                                break;
                        }
                        spaceFreeInIB -= 8;
                }

                result = inputBuffer & (nextBitChange - 1);

               /* if (result == 950)
                        for (int i = 1; i <= stringTable[619].Length(); i++)
                                dest[currentDPos++] = stringTable[619][i];   */

                //frmMonsterBash->Memo2->Lines->Add("Result of " + IntToStr(result) + " at " + IntToStr(currentDPos));

                if (result < nextEntry)
                {
                        //if (specialCase[result])
                        //        frmMonsterBash->Memo2->Lines->Add("Using special case!");
                        newString = stringTable[result];
                        //specialCase.push_back(false);
                }
                else
                {
                        newString = currentString + currentString[1];
                        //frmMonsterBash->Memo2->Lines->Add("Special case");
                        //specialCase.push_back(true);
                }

                if (currentDPos + newString.Length() < sizeDest)
                        aCount = newString.Length();
                else
                        aCount = sizeDest - currentDPos;
                for (int i = 1; i <= aCount; i++)
                        dest[currentDPos++] = newString[i];

                currentString = currentString + newString[1];
                //frmMonsterBash->Memo2->Lines->Add("Wrote out '" + cleanUp(newString) + "', added '" + cleanUp(currentString) + " at " + IntToStr(nextEntry));
                if (addEntries)
                        stringTable.push_back(currentString);
                nextEntry++;
                currentString = newString;

                if (nextEntry == nextBitChange + 1)
                {
                        //frmMonsterBash->Memo2->Lines->Add("OEM here at " + IntToStr(currentDPos));
                        bitBase++;
                        nextBitChange = (int)pow(2, bitBase);
                }

                if (bitBase == maxBitBase + 1)
                {
                    //    return currentDPos;
                        bitBase = maxBitBase;
                        nextBitChange = (int)pow(2, bitBase);
                        addEntries = false;
                  //TODO: if resetAtEnd
                  /*      stringTable.resize(nextEntry / 2);
                        nextEntry /= 2;*/
                    //    currentString = "";
                }

                inputBuffer = inputBuffer >> bitBase;

                if (stillInRange)
                        spaceFreeInIB += bitBase;

         /**/
        }
      //  delete stringTable;
        return currentDPos;
}

//---------------------------------------------------------------------------

#pragma package(smart_init)
