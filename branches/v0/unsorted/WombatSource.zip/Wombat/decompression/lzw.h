//---------------------------------------------------------------------------

#ifndef lzwH
#define lzwH

int unLZW(char * source, char * dest, int sizeSource, int sizeDest, int startBitBase, int maxBitBase, bool resetOnEnd, int firstUsedEntry);
//---------------------------------------------------------------------------
#endif
