// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'MImage.pas' rev: 6.00

#ifndef MImageHPP
#define MImageHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ExtCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Mimage
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TMImage;
class PASCALIMPLEMENTATION TMImage : public Extctrls::TImage 
{
	typedef Extctrls::TImage inherited;
	
public:
	__fastcall virtual TMImage(Classes::TComponent* AOwner);
public:
	#pragma option push -w-inl
	/* TImage.Destroy */ inline __fastcall virtual ~TMImage(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Mimage */
using namespace Mimage;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// MImage
