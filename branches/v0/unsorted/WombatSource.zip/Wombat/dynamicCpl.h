//---------------------------------------------------------------------------

#ifndef dynamicCplH
#define dynamicCplH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "CSPIN.h"
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TfrmDynamicCpl : public TForm
{
__published:	// IDE-managed Components
        TRadioButton *rdbPlanar;
        TRadioButton *rdbHeight;
        TRadioButton *rdbWidth;
        TCSpinEdit *spnWidth;
        TCSpinEdit *spnHeight;
        TCSpinEdit *spnDataStart;
        TCheckBox *chkTransparent;
        TCheckBox *chkReverse;
        TCSpinEdit *spnMaxWidth;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TComboBox *cmbPlaneDraw;
        TCSpinEdit *spnLength;
        TLabel *Label5;
        void __fastcall rdbPlanarClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TfrmDynamicCpl(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmDynamicCpl *frmDynamicCpl;
//---------------------------------------------------------------------------
#endif
