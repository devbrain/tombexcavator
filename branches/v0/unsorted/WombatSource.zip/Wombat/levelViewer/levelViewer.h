//---------------------------------------------------------------------------

#ifndef levelViewerH
#define levelViewerH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <ExtDlgs.hpp>
#include <Menus.hpp>

#include "wombatCommon.h"
//---------------------------------------------------------------------------
class TfrmLevelViewer : public TForm
{
__published:	// IDE-managed Components
        TImage *imgLevel;
        TSavePictureDialog *SavePictureDialog1;
        TMainMenu *MainMenu1;
        TMenuItem *Save1;
        TMenuItem *Currentscreen1;
        TMenuItem *Currentlevel1;
        TMenuItem *Drawforeground1;
        TMenuItem *Foreground1;
        TMenuItem *Properties1;
        TMenuItem *Actors1;
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
private:	// User declarations
public:		// User declarations
        __fastcall TfrmLevelViewer(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmLevelViewer *frmLevelViewer;
extern IWombatGame *levelDriver;
extern TPoint levelOffset;
//---------------------------------------------------------------------------
#endif
