//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "levelViewer.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmLevelViewer *frmLevelViewer;
TPoint levelOffset;
IWombatGame *levelDriver = NULL;
//---------------------------------------------------------------------------
__fastcall TfrmLevelViewer::TfrmLevelViewer(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmLevelViewer::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
        switch (Key){
                case VK_LEFT: if (levelOffset.x > 0)
                              {
                                        levelOffset.x--;
                                        levelDriver->drawLevel(levelOffset);
                              }
                              break;
                case VK_RIGHT: if (levelOffset.x < levelDriver->getLevelWidth() - 40)
                               {
                                        levelOffset.x++;
                                        levelDriver->drawLevel(levelOffset);
                               }
                               break;
                case VK_UP: if (levelOffset.y > 0)
                            {
                                        levelOffset.y--;
                                        levelDriver->drawLevel(levelOffset);
                            }
                              break;
                case VK_DOWN: if (levelOffset.y < levelDriver->getLevelHeight() - 25)
                              {
                                        levelOffset.y++;
                                        levelDriver->drawLevel(levelOffset);
                              }
                              break;
        }
}
//---------------------------------------------------------------------------
