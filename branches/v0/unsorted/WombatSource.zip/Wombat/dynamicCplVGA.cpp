//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "dynamicCplVGA.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
#include "main.h"
TfrmDynamicCplVGA *frmDynamicCplVGA;
//---------------------------------------------------------------------------
__fastcall TfrmDynamicCplVGA::TfrmDynamicCplVGA(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmDynamicCplVGA::spnWidthChange(TObject *Sender)
{
        frmMain->spnPlanesChange(NULL);              
}
//---------------------------------------------------------------------------
