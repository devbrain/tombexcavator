//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <Menus.hpp>
#include <ImgList.hpp>
#include <ExtDlgs.hpp>
#include "CSPIN.h"
#include "MImage.hpp"
#include <MPlayer.hpp>
//---------------------------------------------------------------------------
class TfrmMain : public TForm
{
__published:	// IDE-managed Components
        TTreeView *trvGame;
        TPanel *pnlTop;
        TSpeedButton *spdOpen;
        TOpenDialog *opnOpenFile;
        TPopupMenu *popGame;
        TPanel *pnlMain;
        TMemo *mmoText;
        TImage *imgImage;
        TImageList *imlClosed;
        TSavePictureDialog *svpSave;
        TSaveDialog *svdSave;
        TCSpinButton *cSpinImage;
        TPanel *pnlSpeakerSound;
        TListBox *lstPCSound;
        TMediaPlayer *medMedia;
        TButton *btnPlayPCSound;
        TPanel *pnlLevel;
        TButton *btnViewLevel;
        TLabel *lblDriver;
        TCSpinEdit *spnPlanes;
        TButton *btnProblems;
        TSpeedButton *spdExtract;
        TLabel *Label1;
        TLabel *lblExtract;
        TLabel *lblSaveImage;
        TLabel *Label2;
        TSpeedButton *btnSaveImage;
        void __fastcall spdOpenClick(TObject *Sender);
        void __fastcall trvGameExpanding(TObject *Sender, TTreeNode *Node,
          bool &AllowExpansion);
        void __fastcall trvGameCollapsing(TObject *Sender, TTreeNode *Node,
          bool &AllowCollapse);
        void __fastcall trvGameChange(TObject *Sender, TTreeNode *Node);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall btnSaveImageClick(TObject *Sender);
        void __fastcall spnPlanesChange(TObject *Sender);
        void __fastcall btnPlayPCSoundClick(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall cSpinImageUpClick(TObject *Sender);
        void __fastcall cSpinImageDownClick(TObject *Sender);
        void __fastcall btnViewLevelClick(TObject *Sender);
        void __fastcall spdExtractClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TfrmMain(TComponent* Owner);
        void __fastcall resetControls();
        void __fastcall clearTreeView();
        void __fastcall openFileClick(TObject *Sender);
        void __fastcall openDirClick(TObject *Sender);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmMain *frmMain;
extern char * currentData;
extern int currentDataSize;
extern TPoint bitmapSize;
extern bool isSound;
//---------------------------------------------------------------------------
#endif
