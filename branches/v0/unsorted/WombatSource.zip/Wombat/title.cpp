//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "title.h"
#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmTitle *frmTitle;
//---------------------------------------------------------------------------
__fastcall TfrmTitle::TfrmTitle(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TfrmTitle::Timer1Timer(TObject *Sender)
{
        DWORD oldTime = GetTickCount();
        
        while (GetTickCount() - oldTime < 3000);

        Timer1->Enabled = false;
        ModalResult = 1;
        Close();

}
//---------------------------------------------------------------------------
void __fastcall TfrmTitle::FormCreate(TObject *Sender)
{
        Image1->Cursor = crNone;        
}
//---------------------------------------------------------------------------
