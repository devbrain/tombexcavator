//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("Main.cpp", frmMain);
USEFORM("dynamicCpl.cpp", frmDynamicCpl);
USEFORM("dynamicCplVGA.cpp", frmDynamicCplVGA);
USEFORM("levelViewer\levelViewer.cpp", frmLevelViewer);
USEFORM("title.cpp", frmTitle);
//---------------------------------------------------------------------------
#include "title.h"
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TfrmMain), &frmMain);
                 Application->CreateForm(__classid(TfrmDynamicCpl), &frmDynamicCpl);
                 Application->CreateForm(__classid(TfrmDynamicCplVGA), &frmDynamicCplVGA);
                 Application->CreateForm(__classid(TfrmLevelViewer), &frmLevelViewer);
                 frmTitle = new TfrmTitle(NULL);
                 frmTitle->ShowModal();
                 delete frmTitle;
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        catch (...)
        {
                 try
                 {
                         throw Exception("");
                 }
                 catch (Exception &exception)
                 {
                         Application->ShowException(&exception);
                 }
        }
        return 0;
}
//---------------------------------------------------------------------------
