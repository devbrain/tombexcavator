//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "dynamicCpl.h"
#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
TfrmDynamicCpl *frmDynamicCpl;
//---------------------------------------------------------------------------
__fastcall TfrmDynamicCpl::TfrmDynamicCpl(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmDynamicCpl::rdbPlanarClick(TObject *Sender)
{
        frmMain->spnPlanesChange(NULL);        
}
//---------------------------------------------------------------------------

