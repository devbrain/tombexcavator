//---------------------------------------------------------------------------

#ifndef sndPlayerH
#define sndPlayerH

void loadSndFromMemory(char * file, int size);
void playSound(int sound, bool soundcard);
void cleanUpSound();
//---------------------------------------------------------------------------
#endif
