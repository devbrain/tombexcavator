#!/bin/sh
aclocal
autoheader
autoconf
